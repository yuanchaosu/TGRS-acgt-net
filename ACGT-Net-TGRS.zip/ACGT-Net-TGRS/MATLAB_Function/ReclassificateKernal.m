clc;
clear;
close all;

%% Change DataSet

load('D:\ACGT-Net\IndianPine\Indian.mat');
load('D:\ACGT-Net\IndianPine\Indian_gt.mat');
load('D:\ACGT-Net\IndianPine\IndianPineFullClassMap.mat');

image=image;
image = image(:,:,[1:103, 109:149,164:219]);
GT=GT;
FullClassMap=IndianPineFullClassMap;



% load XiongAn2Cut
% load XiongAn2CutGT
% load XiongAn2FullClassMap
% 
% image=double(XiongAn2Cut);
% GT=double(XiongAn2CutGT);
% FullClassMap=XiongAn2FullClassMap;

%%

image = double(image);
[ind1]=find(GT>0);
com = double(FullClassMap);
com(ind1)=double(GT(ind1));
GT = com;
GT2d=hyperConvert2d(GT);

[hr,wr,bands]=size(image);
nall = hr*wr;
inde = 1:nall;
indexmatrix = reshape(inde,hr,wr);

wopt=5;
nr=hr;nsec=0.1;

load('D:/ACGT-Net/ProcessingData\ClassSize.mat');

[trainImages, trainLabels, trainIndexs] = trainsamples(image,GT,nsec,ClassSize);
[testImages, testLabels, testIndexs] = testsamples(image,GT,trainIndexs);
trainImages=trainImages/max(max(trainImages));
testImages=testImages/max(max(testImages));

I=image;
% I = I(:,:,[1:103, 109:149,164:219]);
% cs=[1,16,20,21,28,32,35,38,42,43,44,45,46,47,49,52,53,54,55,58,62,63,67,68,72,73,75,77,80,82,86,87,92,93,96,98,101,102];

load('D:/ACGT-Net/ProcessingData\sX.mat');
cs=sX;

I = I(:,:,cs);
 [m, n, z] = size(I);
 
% % 
load('D:\ACGT-Net/ProcessingData\TE.mat','TE');
load('D:\ACGT-Net/ProcessingData\TR.mat','TR');

I2d = hyperConvert2d(I);
for i = 1 : z
    I2d(i,:) = mat2gray(I2d(i,:));
end

%加载第一次分类数据
load('D:/ACGT-Net/ProcessingData\feature_map.mat');
Pred_TE3d = feature_map;

%创建检索窗口核
%滑动窗口
% kernalsize=11;
% for i=1:m-kernalsize+1
%     for j=1:n-kernalsize+1
%         target(:,:,(i-1)*(n-kernalsize+1)+j)=Pred_TE3d(i:i+kernalsize-1,j:j+kernalsize-1);
%         Pred_TE3d(i:i+kernalsize-1,j:j+kernalsize-1)
%     end
% end
kernalsize=11;
round=1;
target_index=[];
for i=1:11:m-kernalsize+1
    for j=1:11:n-kernalsize+1
        target(:,:)=Pred_TE3d(i:i+kernalsize-1,j:j+kernalsize-1);
        kernal_sta=reshape(target,121,1);
        table=tabulate(kernal_sta);
        if(table(:,3)~=100)
        [x,y]=find(table==0);
        table(x,:)=[];
        end
        percentage=table(:,3);
        if((0.5<min(percentage(:)))&&(min(percentage(:))<30))
            cut(:,:,round)=Pred_TE3d(i:i+kernalsize-1,j:j+kernalsize-1);
            target_index=[target_index;[i,j]];
            round=round+1;
        end
        Pred_TE3d(i:i+kernalsize-1,j:j+kernalsize-1);
    end
end

cut_image=zeros(hr,wr);

for label_round=1:round-1
    label(:,:,label_round)=TR(target_index(label_round,1):target_index(label_round,1)+10,target_index(label_round,2):target_index(label_round,2)+10);
    cut_image(target_index(label_round,1):target_index(label_round,1)+10,target_index(label_round,2):target_index(label_round,2)+10)=1;
end

wopt=5;


I2d = hyperConvert2d(I);
for i = 1 : z
    I2d(i,:) = mat2gray(I2d(i,:));
end
TR2d = hyperConvert2d(TR);
TE2d = hyperConvert2d(TE);
CI2d=hyperConvert2d(cut_image);

TR_index=find(TR2d>0);
TE_index=find(TE2d>0);
CI_index=find(CI2d>0);
TR_index2=intersect(TR_index,CI_index);
TE_index2=intersect(TE_index,CI_index);
save('D:\ACGT-Net/ProcessingData\TR_index2.mat','TR_index2');
save('D:\ACGT-Net/ProcessingData\TE_index2.mat','TE_index2');

OneInd=ones(1,m*n);

indexs=find(TR2d>0);
testIndexs=find(OneInd>0);
    nDim=z;
    ntrn=length(indexs(:,:));
    ntst=m*n;
    nAll=m*n;
    tempimg=I2d';
    data2=tempimg(:,:);
[ TR_Neighbor, TE_Neighbor]=neighborhood(wopt,hr,indexs,testIndexs,ntrn,ntst,nDim,nAll,data2);

I2d_N=zeros(m*n,z);
I2d_N(indexs,:)=TR_Neighbor(:,:);
I2d_N(testIndexs,:)=TE_Neighbor(:,:);
I2d_N=I2d_N';


TR_sample = I2d_N(:,TR_index);
TE_sample_total = I2d_N(:,TE_index2);

TR_temp = TR2d(:,TR_index);
TE_temp_total = TE2d(:,TE_index2);

X = [TR_sample,TE_sample_total];
Y = [TR_temp, TE_temp_total];

Rturns=floor(size(TE_temp_total,2)/7000);
RMod=mod(size(TE_temp_total,2),7000);

for i=1:floor(size(TE_temp_total,2)/7000)

TE_sample=TE_sample_total(:,(i-1)*7000+1:i*7000);
TE_temp=TE_temp_total(:,(i-1)*7000+1:i*7000);

%原图像权制作
K = 10;
si = 1;
Train_W_r = creatLap(TR_sample, K, si);
Train_D_r = (sum(Train_W_r, 2)).^(-1/2);
Train_D_r = diag(Train_D_r);
L_temp_r = Train_W_r * Train_D_r;
Train_L_r = Train_D_r * L_temp_r;
Train_L_r = Train_L_r + eye(size(Train_L_r));

Test_W_r = creatLap(TE_sample, K, si); 
Test_D_r = (sum(Test_W_r, 2)).^(-1/2);
Test_D_r = diag(Test_D_r);
L_temp_r = Test_W_r * Test_D_r;
Test_L_r = Test_D_r * L_temp_r;
Test_L_r = Test_L_r + eye(size(Test_L_r));

Train_X_r = TR_sample';
Test_X_r = TE_sample';
TrLabel_r = TR_temp';
TeLabel_r = TE_temp';

add=num2str(i);
%% Please replace the following route with your own one
save(['D:\ACGT-Net\HSI_GCN/Train_X_r',add,'.mat'],'Train_X_r');
save(['D:\ACGT-Net\HSI_GCN/Test_X_r',add,'.mat'],'Test_X_r');
save(['D:\ACGT-Net\HSI_GCN/TrLabel_r',add,'.mat'],'TrLabel_r');
save(['D:\ACGT-Net\HSI_GCN/TeLabel_r',add,'.mat'],'TeLabel_r');
save(['D:\ACGT-Net\HSI_GCN/Train_L_r',add,'.mat'],'Train_L_r');
save(['D:\ACGT-Net\HSI_GCN/Test_L_r',add,'.mat'],'Test_L_r');
save('D:\ACGT-Net\ProcessingData\cut_image.mat','cut_image')
save('D:\ACGT-Net\ProcessingData\TR_index2.mat','TR_index2')
save('D:\ACGT-Net\ProcessingData\TE_index2.mat','TE_index2')

fprintf('%sth ClassCUt Finished\n',add);
end

if(RMod~=0)

    i=i+1;
    Rturns=Rturns+1;

    TE_sample=TE_sample_total(:,(i-1)*7000+1:size(TE_temp_total,2));
    TE_temp=TE_temp_total(:,(i-1)*7000+1:size(TE_temp_total,2));

    %原图像权制作
    K = 10;
    si = 1;
    Train_W_r = creatLap(TR_sample, K, si);
    Train_D_r = (sum(Train_W_r, 2)).^(-1/2);
    Train_D_r = diag(Train_D_r);
    L_temp_r = Train_W_r * Train_D_r;
    Train_L_r = Train_D_r * L_temp_r;
    Train_L_r = Train_L_r + eye(size(Train_L_r));

    Test_W_r = creatLap(TE_sample, K, si); 
    Test_D_r = (sum(Test_W_r, 2)).^(-1/2);
    Test_D_r = diag(Test_D_r);
    L_temp_r = Test_W_r * Test_D_r;
    Test_L_r = Test_D_r * L_temp_r;
    Test_L_r = Test_L_r + eye(size(Test_L_r));

    Train_X_r = TR_sample';
    Test_X_r = TE_sample';
    TrLabel_r = TR_temp';
    TeLabel_r = TE_temp';

    add=num2str(i);
    %% Please replace the following route with your own one
    save(['D:\ACGT-Net\HSI_GCN/Train_X_r',add,'.mat'],'Train_X_r');
    save(['D:\ACGT-Net\HSI_GCN/Test_X_r',add,'.mat'],'Test_X_r');
    save(['D:\ACGT-Net\HSI_GCN/TrLabel_r',add,'.mat'],'TrLabel_r');
    save(['D:\ACGT-Net\HSI_GCN/TeLabel_r',add,'.mat'],'TeLabel_r');
    save(['D:\ACGT-Net\HSI_GCN/Train_L_r',add,'.mat'],'Train_L_r');
    save(['D:\ACGT-Net\HSI_GCN/Test_L_r',add,'.mat'],'Test_L_r');
    save('D:\ACGT-Net\ProcessingData\cut_image.mat','cut_image')
    save('D:\ACGT-Net\ProcessingData\TR_index2.mat','TR_index2')
    save('D:\ACGT-Net\ProcessingData\TE_index2.mat','TE_index2')
    fprintf('%sth ClassCUt Finished\n',add);
    fprintf('Outset Has Been Put\n\n');
    
    save('D:\ACGT-Net\ProcessingData\Rturns.mat','Rturns');

end

%%

function [ XTrnm , XTstm]=neighborhood(wopt,nr,indexs,testIndexs,ntrn,ntst,nDim,nAll,data2)  %5,145,[1,1043],[9323,1],1043,9323,20,21025,[21025,20],27.0464
  w = wopt; wc = (w-1)/2;  vv = -wc : wc;
        idw0 = repmat(vv*nr,w,1) + repmat(vv',1,w);
        idw0 = reshape(idw0,1,w*w);          %[1,25]
        XTrnm   = zeros(ntrn, nDim);         %[1043,200]
        XTstm   = zeros(ntst, nDim);         %[9323,200]
        for i = 1 : ntrn                     %1:1043
            idw = idw0 + indexs(i); idw = [indexs(i) idw]; idw((w^2+1)/2+1)=[];
            idw(idw>nAll | idw<1) = [];      %idw中存放的是indexs[i]周围的元素的地址 
         
            Xtmp = data2(idw,:);            %[25,20]
             XTrnm(i,:)   = mean(Xtmp,1);   %把Xtmp的每一列取平均值 得到一行20列的数组复制给XTrnm(i,:) 得到了训练样本的周围元素的均值
        end
       
        for i = 1 : ntst                    %1：9323
            idw = idw0 + testIndexs(i); idw = [testIndexs(i) idw]; idw((w^2+1)/2+1)=[];
            idw(idw>nAll | idw<1) = [];     %idw中存放的是测试样本周围的元素的地址 
           
            Xtmp = data2(idw,:); 
              XTstm(i,:)   = mean(Xtmp,1); %得到了测试样本的周围元素的均值[1,20]
           
        end
        XTrnm= XTrnm./10;         %训练样本周围元素的均值与训练样本同维
         XTstm= XTstm./10;        %测试样本周围元素的均值与测试样本同维
%         XTrnm= XTrnm./9604;         %训练样本周围元素的均值与训练样本同维
%          XTstm= XTstm./9604;        %测试样本周围元素的均值与测试样本同维
%         XTrnmL2 = XTrnm./ repmat(sqrt(sum(XTrnm.*XTrnm,2)),[1 nDim]); % L2 norm 得到的空间信息同样每个元素除以自己的范数
%         XTstmL2 = XTstm./ repmat(sqrt(sum(XTstm.*XTstm,2)),[1 nDim]); % L2 norm
end

function [M] = hyperConvert2d(M)
% HYPERCONVERT2D Converts an HSI cube to a 2D matrix
% Converts a 3D HSI cube (m x n x p) to a 2D matrix of points (p X N)
% where N = mn
%
% Usage
%   [M] = hyperConvert2d(M)
% Inputs
%   M - 3D HSI cube (m x n x p)
% Outputs
%   M - 2D data matrix (p x N)

if (ndims(M)>3 || ndims(M)<2)
    error('Input image must be m x n x p or m x n');
end
if (ndims(M) == 2)
    numBands = 1;
    [h, w] = size(M);
else
    [h, w, numBands] = size(M);
end

M = reshape(M, w*h, numBands).';

end

function [W, D, L]=creatLap(X,k,sigma) 
      X=X';
      options = [];
      options.NeighborMode = 'KNN';
      options.k = k;
      options.WeightMode = 'HeatKernel';
      options.t = sigma;

      W = (constructW(X, options));
      D = (diag(sum(W, 2)));
      L = D - W;
end

function D = EuDist2(fea_a,fea_b,bSqrt)
%EUDIST2 Efficiently Compute the Euclidean Distance Matrix by Exploring the
%Matlab matrix operations.
%
%   D = EuDist(fea_a,fea_b)
%   fea_a:    nSample_a * nFeature
%   fea_b:    nSample_b * nFeature
%   D:      nSample_a * nSample_a
%       or  nSample_a * nSample_b
%
%    Examples:
%
%       a = rand(500,10);
%       b = rand(1000,10);
%
%       A = EuDist2(a); % A: 500*500
%       D = EuDist2(a,b); % D: 500*1000
%
%   version 2.1 --November/2011
%   version 2.0 --May/2009
%   version 1.0 --November/2005
%
%   Written by Deng Cai (dengcai AT gmail.com)


if ~exist('bSqrt','var')
    bSqrt = 1;
end

if (~exist('fea_b','var')) || isempty(fea_b)
    aa = sum(fea_a.*fea_a,2);
    ab = fea_a*fea_a';
    
    if issparse(aa)
        aa = full(aa);
    end
    
    D = bsxfun(@plus,aa,aa') - 2*ab;
    D(D<0) = 0;
    if bSqrt
        D = sqrt(D);
    end
    D = max(D,D');
else
    aa = sum(fea_a.*fea_a,2);
    bb = sum(fea_b.*fea_b,2);
    ab = fea_a*fea_b';

    if issparse(aa)
        aa = full(aa);
        bb = full(bb);
    end

    D = bsxfun(@plus,aa,bb') - 2*ab;
    D(D<0) = 0;
    if bSqrt
        D = sqrt(D);
    end
end
end

function W = constructW(fea,options)
%	Usage:
%	W = constructW(fea,options)
%
%	fea: Rows of vectors of data points. Each row is x_i
%   options: Struct value in Matlab. The fields in options that can be set:
%                  
%           NeighborMode -  Indicates how to construct the graph. Choices
%                           are: [Default 'KNN']
%                'KNN'            -  k = 0
%                                       Complete graph
%                                    k > 0
%                                      Put an edge between two nodes if and
%                                      only if they are among the k nearst
%                                      neighbors of each other. You are
%                                      required to provide the parameter k in
%                                      the options. Default k=5.
%               'Supervised'      -  k = 0
%                                       Put an edge between two nodes if and
%                                       only if they belong to same class. 
%                                    k > 0
%                                       Put an edge between two nodes if
%                                       they belong to same class and they
%                                       are among the k nearst neighbors of
%                                       each other. 
%                                    Default: k=0
%                                   You are required to provide the label
%                                   information gnd in the options.
%                                              
%           WeightMode   -  Indicates how to assign weights for each edge
%                           in the graph. Choices are:
%               'Binary'       - 0-1 weighting. Every edge receiveds weight
%                                of 1. 
%               'HeatKernel'   - If nodes i and j are connected, put weight
%                                W_ij = exp(-norm(x_i - x_j)/2t^2). You are 
%                                required to provide the parameter t. [Default One]
%               'Cosine'       - If nodes i and j are connected, put weight
%                                cosine(x_i,x_j). 
%               
%            k         -   The parameter needed under 'KNN' NeighborMode.
%                          Default will be 5.
%            gnd       -   The parameter needed under 'Supervised'
%                          NeighborMode.  Colunm vector of the label
%                          information for each data point.
%            bLDA      -   0 or 1. Only effective under 'Supervised'
%                          NeighborMode. If 1, the graph will be constructed
%                          to make LPP exactly same as LDA. Default will be
%                          0. 
%            t         -   The parameter needed under 'HeatKernel'
%                          WeightMode. Default will be 1
%         bNormalized  -   0 or 1. Only effective under 'Cosine' WeightMode.
%                          Indicates whether the fea are already be
%                          normalized to 1. Default will be 0
%      bSelfConnected  -   0 or 1. Indicates whether W(i,i) == 1. Default 0
%                          if 'Supervised' NeighborMode & bLDA == 1,
%                          bSelfConnected will always be 1. Default 0.
%            bTrueKNN  -   0 or 1. If 1, will construct a truly kNN graph
%                          (Not symmetric!). Default will be 0. Only valid
%                          for 'KNN' NeighborMode
%
%
%    Examples:
%
%       fea = rand(50,15);
%       options = [];
%       options.NeighborMode = 'KNN';
%       options.k = 5;
%       options.WeightMode = 'HeatKernel';
%       options.t = 1;
%       W = constructW(fea,options);
%       
%       
%       fea = rand(50,15);
%       gnd = [ones(10,1);ones(15,1)*2;ones(10,1)*3;ones(15,1)*4];
%       options = [];
%       options.NeighborMode = 'Supervised';
%       options.gnd = gnd;
%       options.WeightMode = 'HeatKernel';
%       options.t = 1;
%       W = constructW(fea,options);
%       
%       
%       fea = rand(50,15);
%       gnd = [ones(10,1);ones(15,1)*2;ones(10,1)*3;ones(15,1)*4];
%       options = [];
%       options.NeighborMode = 'Supervised';
%       options.gnd = gnd;
%       options.bLDA = 1;
%       W = constructW(fea,options);      
%       
%
%    For more details about the different ways to construct the W, please
%    refer:
%       Deng Cai, Xiaofei He and Jiawei Han, "Document Clustering Using
%       Locality Preserving Indexing" IEEE TKDE, Dec. 2005.
%    
%
%    Written by Deng Cai (dengcai2 AT cs.uiuc.edu), April/2004, Feb/2006,
%                                             May/2007
% 
% fea=normlizedW(fea',0);
% fea=fea';
bSpeed  = 1;

if (~exist('options','var'))
   options = [];
end

if isfield(options,'Metric')
    warning('This function has been changed and the Metric is no longer be supported');
end


if ~isfield(options,'bNormalized')
    options.bNormalized = 0;
end

%=================================================
if ~isfield(options,'NeighborMode')
    options.NeighborMode = 'KNN';
end

switch lower(options.NeighborMode)
    case {lower('KNN')}  %For simplicity, we include the data point itself in the kNN
        if ~isfield(options,'k')
            options.k = 5;
        end
    case {lower('Supervised')}
        if ~isfield(options,'bLDA')
            options.bLDA = 0;
        end
        if options.bLDA
            options.bSelfConnected = 1;
        end
        if ~isfield(options,'k')
            options.k = 0;
        end
        if ~isfield(options,'gnd')
            error('Label(gnd) should be provided under ''Supervised'' NeighborMode!');
        end
        if ~isempty(fea) && length(options.gnd) ~= size(fea,1)
            error('gnd doesn''t match with fea!');
        end
    otherwise
        error('NeighborMode does not exist!');
end

%=================================================

if ~isfield(options,'WeightMode')
    options.WeightMode = 'HeatKernel';
end

bBinary = 0;
bCosine = 0;
switch lower(options.WeightMode)
    case {lower('Binary')}
        bBinary = 1; 
    case {lower('HeatKernel')}
        if ~isfield(options,'t')
            nSmp = size(fea,1);
            if nSmp > 3000
                D = EuDist2(fea(randsample(nSmp,3000),:));
            else
                D = EuDist2(fea);
            end
            options.t = mean(mean(D));
        end
    case {lower('Cosine')}
        bCosine = 1;
    otherwise
        error('WeightMode does not exist!');
end

%=================================================

if ~isfield(options,'bSelfConnected')
    options.bSelfConnected = 0;
end

%=================================================

if isfield(options,'gnd') 
    nSmp = length(options.gnd);
else
    nSmp = size(fea,1);
end
maxM = 62500000; %500M
BlockSize = floor(maxM/(nSmp*3));


if strcmpi(options.NeighborMode,'Supervised')
    Label = unique(options.gnd);
    nLabel = length(Label);
    if options.bLDA
        G = zeros(nSmp,nSmp);
        for idx=1:nLabel
            classIdx = options.gnd==Label(idx);
            G(classIdx,classIdx) = 1/sum(classIdx);
        end
        W = sparse(G);
        return;
    end
    
    switch lower(options.WeightMode)
        case {lower('Binary')}
            if options.k > 0
                G = zeros(nSmp*(options.k+1),3);
                idNow = 0;
                for i=1:nLabel
                    classIdx = find(options.gnd==Label(i));
                    D = EuDist2(fea(classIdx,:),[],0);
                    [dump idx] = sort(D,2); % sort each row
                    clear D dump;
                    idx = idx(:,1:options.k+1);
                    
                    nSmpClass = length(classIdx)*(options.k+1);
                    G(idNow+1:nSmpClass+idNow,1) = repmat(classIdx,[options.k+1,1]);
                    G(idNow+1:nSmpClass+idNow,2) = classIdx(idx(:));
                    G(idNow+1:nSmpClass+idNow,3) = 1;
                    idNow = idNow+nSmpClass;
                    clear idx
                end
                G = sparse(G(:,1),G(:,2),G(:,3),nSmp,nSmp);
                G = max(G,G');
            else
                G = zeros(nSmp,nSmp);
                for i=1:nLabel
                    classIdx = find(options.gnd==Label(i));
                    G(classIdx,classIdx) = 1;
                end
            end
            
            if ~options.bSelfConnected
                for i=1:size(G,1)
                    G(i,i) = 0;
                end
            end
            
            W = sparse(G);
        case {lower('HeatKernel')}
            if options.k > 0
                G = zeros(nSmp*(options.k+1),3);
                idNow = 0;
                for i=1:nLabel
                    classIdx = find(options.gnd==Label(i));
                    D = EuDist2(fea(classIdx,:),[],0);
                    [dump idx] = sort(D,2); % sort each row
                    clear D;
                    idx = idx(:,1:options.k+1);
                    dump = dump(:,1:options.k+1);
                    dump = exp(-dump/(2*options.t^2));
                    
                    nSmpClass = length(classIdx)*(options.k+1);
                    G(idNow+1:nSmpClass+idNow,1) = repmat(classIdx,[options.k+1,1]);
                    G(idNow+1:nSmpClass+idNow,2) = classIdx(idx(:));
                    G(idNow+1:nSmpClass+idNow,3) = dump(:);
                    idNow = idNow+nSmpClass;
                    clear dump idx
                end
                G = sparse(G(:,1),G(:,2),G(:,3),nSmp,nSmp);
            else
                G = zeros(nSmp,nSmp);
                for i=1:nLabel
                    classIdx = find(options.gnd==Label(i));
                    D = EuDist2(fea(classIdx,:),[],0);
                    D = exp(-D/(2*options.t^2));
                    G(classIdx,classIdx) = D;
                end
            end
            
            if ~options.bSelfConnected
                for i=1:size(G,1)
                    G(i,i) = 0;
                end
            end

            W = sparse(max(G,G'));
        case {lower('Cosine')}
            if ~options.bNormalized
                fea = NormalizeFea(fea);
            end

            if options.k > 0
                G = zeros(nSmp*(options.k+1),3);
                idNow = 0;
                for i=1:nLabel
                    classIdx = find(options.gnd==Label(i));
                    D = fea(classIdx,:)*fea(classIdx,:)';
                    [dump idx] = sort(-D,2); % sort each row
                    clear D;
                    idx = idx(:,1:options.k+1);
                    dump = -dump(:,1:options.k+1);
                    
                    nSmpClass = length(classIdx)*(options.k+1);
                    G(idNow+1:nSmpClass+idNow,1) = repmat(classIdx,[options.k+1,1]);
                    G(idNow+1:nSmpClass+idNow,2) = classIdx(idx(:));
                    G(idNow+1:nSmpClass+idNow,3) = dump(:);
                    idNow = idNow+nSmpClass;
                    clear dump idx
                end
                G = sparse(G(:,1),G(:,2),G(:,3),nSmp,nSmp);
            else
                G = zeros(nSmp,nSmp);
                for i=1:nLabel
                    classIdx = find(options.gnd==Label(i));
                    G(classIdx,classIdx) = fea(classIdx,:)*fea(classIdx,:)';
                end
            end

            if ~options.bSelfConnected
                for i=1:size(G,1)
                    G(i,i) = 0;
                end
            end

            W = sparse(max(G,G'));
        otherwise
            error('WeightMode does not exist!');
    end
    return;
end


if bCosine && ~options.bNormalized
    Normfea = NormalizeFea(fea);
end

if strcmpi(options.NeighborMode,'KNN') && (options.k > 0)
    if ~(bCosine && options.bNormalized)
        G = zeros(nSmp*(options.k+1),3);
        for i = 1:ceil(nSmp/BlockSize)
            if i == ceil(nSmp/BlockSize)
                smpIdx = (i-1)*BlockSize+1:nSmp;
                dist = EuDist2(fea(smpIdx,:),fea,0);
                if bSpeed
                    nSmpNow = length(smpIdx);
                    dump = zeros(nSmpNow,options.k+1);
                    idx = dump;
                    for j = 1:options.k+1
                        [dump(:,j),idx(:,j)] = min(dist,[],2);
                        temp = (idx(:,j)-1)*nSmpNow+[1:nSmpNow]';
                        dist(temp) = 1e100;
                    end
                else
                    [dump idx] = sort(dist,2); % sort each row
                    idx = idx(:,1:options.k+1);
                    dump = dump(:,1:options.k+1);
                end
                
                if ~bBinary
                    if bCosine
                        dist = Normfea(smpIdx,:)*Normfea';
                        dist = full(dist);
                        linidx = [1:size(idx,1)]';
                        dump = dist(sub2ind(size(dist),linidx(:,ones(1,size(idx,2))),idx));
                    else
                        dump = exp(-dump/(2*options.t^2));
                    end
                end
                
                G((i-1)*BlockSize*(options.k+1)+1:nSmp*(options.k+1),1) = repmat(smpIdx',[options.k+1,1]);
                G((i-1)*BlockSize*(options.k+1)+1:nSmp*(options.k+1),2) = idx(:);
                if ~bBinary
                    G((i-1)*BlockSize*(options.k+1)+1:nSmp*(options.k+1),3) = dump(:);
                else
                    G((i-1)*BlockSize*(options.k+1)+1:nSmp*(options.k+1),3) = 1;
                end
            else
                smpIdx = (i-1)*BlockSize+1:i*BlockSize;
            
                dist = EuDist2(fea(smpIdx,:),fea,0);
                
                if bSpeed
                    nSmpNow = length(smpIdx);
                    dump = zeros(nSmpNow,options.k+1);
                    idx = dump;
                    for j = 1:options.k+1
                        [dump(:,j),idx(:,j)] = min(dist,[],2);
                        temp = (idx(:,j)-1)*nSmpNow+[1:nSmpNow]';
                        dist(temp) = 1e100;
                    end
                else
                    [dump idx] = sort(dist,2); % sort each row
                    idx = idx(:,1:options.k+1);
                    dump = dump(:,1:options.k+1);
                end
                
                if ~bBinary
                    if bCosine
                        dist = Normfea(smpIdx,:)*Normfea';
                        dist = full(dist);
                        linidx = [1:size(idx,1)]';
                        dump = dist(sub2ind(size(dist),linidx(:,ones(1,size(idx,2))),idx));
                    else
                        dump = exp(-dump/(2*options.t^2));
                    end
                end
                
                G((i-1)*BlockSize*(options.k+1)+1:i*BlockSize*(options.k+1),1) = repmat(smpIdx',[options.k+1,1]);
                G((i-1)*BlockSize*(options.k+1)+1:i*BlockSize*(options.k+1),2) = idx(:);
                if ~bBinary
                    G((i-1)*BlockSize*(options.k+1)+1:i*BlockSize*(options.k+1),3) = dump(:);
                else
                    G((i-1)*BlockSize*(options.k+1)+1:i*BlockSize*(options.k+1),3) = 1;
                end
            end
        end

        W = sparse(G(:,1),G(:,2),G(:,3),nSmp,nSmp);
    else
        G = zeros(nSmp*(options.k+1),3);
        for i = 1:ceil(nSmp/BlockSize)
            if i == ceil(nSmp/BlockSize)
                smpIdx = (i-1)*BlockSize+1:nSmp;
                dist = fea(smpIdx,:)*fea';
                dist = full(dist);
                if bSpeed
                    nSmpNow = length(smpIdx);
                    dump = zeros(nSmpNow,options.k+1);
                    idx = dump;
                    for j = 1:options.k+1
                        [dump(:,j),idx(:,j)] = max(dist,[],2);
                        temp = (idx(:,j)-1)*nSmpNow+[1:nSmpNow]';
                        dist(temp) = 0;
                    end
                else
                    [dump idx] = sort(-dist,2); % sort each row
                    idx = idx(:,1:options.k+1);
                    dump = -dump(:,1:options.k+1);
                end

                G((i-1)*BlockSize*(options.k+1)+1:nSmp*(options.k+1),1) = repmat(smpIdx',[options.k+1,1]);
                G((i-1)*BlockSize*(options.k+1)+1:nSmp*(options.k+1),2) = idx(:);
                G((i-1)*BlockSize*(options.k+1)+1:nSmp*(options.k+1),3) = dump(:);
            else
                smpIdx = (i-1)*BlockSize+1:i*BlockSize;
                dist = fea(smpIdx,:)*fea';
                dist = full(dist);
                
                if bSpeed
                    nSmpNow = length(smpIdx);
                    dump = zeros(nSmpNow,options.k+1);
                    idx = dump;
                    for j = 1:options.k+1
                        [dump(:,j),idx(:,j)] = max(dist,[],2);
                        temp = (idx(:,j)-1)*nSmpNow+[1:nSmpNow]';
                        dist(temp) = 0;
                    end
                else
                    [dump idx] = sort(-dist,2); % sort each row
                    idx = idx(:,1:options.k+1);
                    dump = -dump(:,1:options.k+1);
                end

                G((i-1)*BlockSize*(options.k+1)+1:i*BlockSize*(options.k+1),1) = repmat(smpIdx',[options.k+1,1]);
                G((i-1)*BlockSize*(options.k+1)+1:i*BlockSize*(options.k+1),2) = idx(:);
                G((i-1)*BlockSize*(options.k+1)+1:i*BlockSize*(options.k+1),3) = dump(:);
            end
        end

        W = sparse(G(:,1),G(:,2),G(:,3),nSmp,nSmp);
    end
    
    if bBinary
        W(logical(W)) = 1;
    end
    
    if isfield(options,'bSemiSupervised') && options.bSemiSupervised
        tmpgnd = options.gnd(options.semiSplit);
        
        Label = unique(tmpgnd);
        nLabel = length(Label);
        G = zeros(sum(options.semiSplit),sum(options.semiSplit));
        for idx=1:nLabel
            classIdx = tmpgnd==Label(idx);
            G(classIdx,classIdx) = 1;
        end
        Wsup = sparse(G);
        if ~isfield(options,'SameCategoryWeight')
            options.SameCategoryWeight = 1;
        end
        W(options.semiSplit,options.semiSplit) = (Wsup>0)*options.SameCategoryWeight;
    end
    
    if ~options.bSelfConnected
        W = W - diag(diag(W));
    end

    if isfield(options,'bTrueKNN') && options.bTrueKNN
        
    else
        W = max(W,W');
    end
    
    return;
end
end

function [images, labels, indexs] = trainsamples(img, gt,nsec,ClassSize)
% 生成实验1的训练样本
indexs = [];
% labels = [];
a=zeros(ClassSize,1);
for j=1:ClassSize
    a(j)=length(find(gt==j));
end
for i = 1 : ClassSize
%      nuse = min(nsec, round(a(i)/2) ); 
      nuse = ceil(a(i)*nsec);
    switch i
%         case 1
%             tempindex = find(gt == 1);
%             tempindex=tempindex';                          %tempindex是列向量
%             rp=randperm(length(tempindex));                %不重复的随机打乱1-length（tempindex）
%             indexs=[indexs tempindex(rp(1: 548))];           %随机选6个类是1的地址赋值给indexs
%         case 2
%             tempindex = find(gt == 2);
%             tempindex=tempindex';
%             rp=randperm(length(tempindex));
%             indexs=[indexs tempindex(rp(1:540))];
%         case 3
%             tempindex = find(gt == 3);
%             tempindex=tempindex';
%             rp=randperm(length(tempindex));
%             indexs=[indexs tempindex(rp(1: 392))];
%         case 4
%             tempindex = find(gt == 4);
%             tempindex=tempindex';
%             rp=randperm(length(tempindex));
%             indexs=[indexs tempindex(rp(1: 542))];
%         case 5
%             tempindex = find(gt == 5);
%             tempindex=tempindex';
%             rp=randperm(length(tempindex));
%             indexs=[indexs tempindex(rp(1: 265))];
%         case 6
%             tempindex = find(gt == 6);
%             tempindex=tempindex';
%             rp=randperm(length(tempindex));
%             indexs=[indexs tempindex(rp(1: 532))];
%         case 7
%             tempindex = find(gt == 7);
%             tempindex=tempindex';
%             rp=randperm(length(tempindex));
%             indexs=[indexs tempindex(rp(1: 375))];
%         case 8
%             tempindex = find(gt == 8);
%             tempindex=tempindex';
%             rp=randperm(length(tempindex));
%             indexs=[indexs tempindex(rp(1: 514))];
%         case 9
%             tempindex = find(gt == 9);
%             tempindex=tempindex';
%             rp=randperm(length(tempindex));
%              indexs=[indexs tempindex(rp(1: 231))];

        case 1
            tempindex = find(gt == 1);
            tempindex=tempindex';
            rp=randperm(length(tempindex));
             indexs=[indexs tempindex(rp(1: nuse))];
        case 2
            tempindex = find(gt == 2);
            tempindex=tempindex';
            rp=randperm(length(tempindex));
             indexs=[indexs tempindex(rp(1: nuse))];
        case 3
            tempindex = find(gt == 3);
            tempindex=tempindex';
            rp=randperm(length(tempindex));
             indexs=[indexs tempindex(rp(1: nuse))];
         case 4
            tempindex = find(gt == 4);
            tempindex=tempindex';
            rp=randperm(length(tempindex));
             indexs=[indexs tempindex(rp(1: nuse))];
        case 5
            tempindex = find(gt == 5);
            tempindex=tempindex';
            rp=randperm(length(tempindex));
             indexs=[indexs tempindex(rp(1: nuse))];
        case 6
            tempindex = find(gt == 6);
            tempindex=tempindex';
            rp=randperm(length(tempindex));
             indexs=[indexs tempindex(rp(1: nuse))];
        case 7
            tempindex = find(gt == 7);
            tempindex=tempindex';
            rp=randperm(length(tempindex));
             indexs=[indexs tempindex(rp(1: nuse))];
         case 8
            tempindex = find(gt == 8);
            tempindex=tempindex';
            rp=randperm(length(tempindex));
             indexs=[indexs tempindex(rp(1: nuse))];
         case 9
            tempindex = find(gt == 9);
            tempindex=tempindex';
            rp=randperm(length(tempindex));
             indexs=[indexs tempindex(rp(1: nuse))];
        case 10
            tempindex = find(gt == 10);
            tempindex=tempindex';
            rp=randperm(length(tempindex));
             indexs=[indexs tempindex(rp(1: nuse))];
        case 11
            tempindex = find(gt == 11);
            tempindex=tempindex';
            rp=randperm(length(tempindex));
             indexs=[indexs tempindex(rp(1: nuse))];
        case 12
            tempindex = find(gt == 12);
            tempindex=tempindex';
            rp=randperm(length(tempindex));
             indexs=[indexs tempindex(rp(1: nuse))];
         case 13
            tempindex = find(gt == 13);
            tempindex=tempindex';
            rp=randperm(length(tempindex));
             indexs=[indexs tempindex(rp(1: nuse))];
          case 14
            tempindex = find(gt == 14);
            tempindex=tempindex';
            rp=randperm(length(tempindex));
             indexs=[indexs tempindex(rp(1: nuse))];
          case 15
            tempindex = find(gt == 15);
            tempindex=tempindex';
            rp=randperm(length(tempindex));
             indexs=[indexs tempindex(rp(1: nuse))];
          case 16
            tempindex = find(gt == 16);
            tempindex=tempindex';
            rp=randperm(length(tempindex));
             indexs=[indexs tempindex(rp(1: nuse))];    
%         case 1
%             tempindex = find(gt == 1);
%             tempindex=tempindex';                          %tempindex是列向量
%             rp=randperm(length(tempindex));                %不重复的随机打乱1-length（tempindex）
%              indexs=[indexs tempindex(rp(1:6))];           %随机选6个类是1的地址赋值给indexs
%         case 2
%             tempindex = find(gt == 2);
%             tempindex=tempindex';
%             rp=randperm(length(tempindex));
%             indexs=[indexs tempindex(rp(1:144))];
%         case 3
%             tempindex = find(gt == 3);
%             tempindex=tempindex';
%             rp=randperm(length(tempindex));
%             indexs=[indexs tempindex(rp(1:84))];
%         case 4
%             tempindex = find(gt == 4);
%             tempindex=tempindex';
%             rp=randperm(length(tempindex));
%             indexs=[indexs tempindex(rp(1:24))];
%         case 5
%             tempindex = find(gt == 5);
%             tempindex=tempindex';
%             rp=randperm(length(tempindex));
%             indexs=[indexs tempindex(rp(1:50))];
%         case 6
%             tempindex = find(gt == 6);
%             tempindex=tempindex';
%             rp=randperm(length(tempindex));
%             indexs=[indexs tempindex(rp(1:75))];
%         case 7
%             tempindex = find(gt == 7);
%             tempindex=tempindex';
%             rp=randperm(length(tempindex));
%             indexs=[indexs tempindex(rp(1:3))];
%         case 8
%             tempindex = find(gt == 8);
%             tempindex=tempindex';
%             rp=randperm(length(tempindex));
%             indexs=[indexs tempindex(rp(1:49))];
%         case 9
%             tempindex = find(gt == 9);
%             tempindex=tempindex';
%             rp=randperm(length(tempindex));
%              indexs=[indexs tempindex(rp(1:2))];
%         case 10
%             tempindex = find(gt == 10);
%             tempindex=tempindex';
%             rp=randperm(length(tempindex));
%              indexs=[indexs tempindex(rp(1:97))];
%         case 11
%             tempindex = find(gt == 11);
%             tempindex=tempindex';
%             rp=randperm(length(tempindex));
%              indexs=[indexs tempindex(rp(1:247))];
%         case 12
%             tempindex = find(gt == 12);
%             tempindex=tempindex';
%             rp=randperm(length(tempindex));
%              indexs=[indexs tempindex(rp(1:62))];
%          case 13
%             tempindex = find(gt == 13);
%             tempindex=tempindex';
%             rp=randperm(length(tempindex));
%              indexs=[indexs tempindex(rp(1:22))];
%           case 14
%             tempindex = find(gt == 14);
%             tempindex=tempindex';
%             rp=randperm(length(tempindex));
%              indexs=[indexs tempindex(rp(1:130))];
%           case 15
%             tempindex = find(gt == 15);
%             tempindex=tempindex';
%             rp=randperm(length(tempindex));
%              indexs=[indexs tempindex(rp(1:38))];
%           case 16
%             tempindex = find(gt == 16);
%             tempindex=tempindex';
%             rp=randperm(length(tempindex));
%              indexs=[indexs tempindex(rp(1:10))];    
    end
end



labels = gt(indexs);
labels = double(labels);

[nr,nc,ndim]=size(img);
nall=nr*nc;
tempimg=reshape(img,nall,ndim);       
% bandmaxvalue=max(tempimg(:));                           %样本（21025*200）的最大值
images = (tempimg(indexs, :))';                         %筛选样本得到一个1043*200的训练样本       

             %将训练样本转置再除以最大值，得到（0-1）的200*1043训练样本
%         images1= images./ repmat(sqrt(sum(images.*images,2)),[1 200]); 
%         images2=images1';


end

function [images, labels, indexs,tempimg,maxmun] = testsamples(img, gt,trainindexs)
% 生成实验1的测试样本
imgsize = size(img);
num = imgsize(1)*imgsize(2);     %20245
indexs = [];
gt(trainindexs)=0;             %gt145*145

for i = 1 : num                  %1:20245
    if gt(i) ~= 0
        indexs = [indexs; i];      %把类不是0的地址存进indexs
    end
end

labels = gt(indexs);
[nr,nc,ndim]=size(img);
nall=nr*nc;
tempimg = reshape(img, nall,ndim);
maxmun=max(tempimg(:));
images = tempimg(indexs,:);
images = double(images'./65517);
%  images1 = images./ repmat(sqrt(sum(images.*images,2)),[1 200]);
%  images2=images1';
end
