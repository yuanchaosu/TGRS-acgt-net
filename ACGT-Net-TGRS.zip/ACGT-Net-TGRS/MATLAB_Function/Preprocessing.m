
clc;
clear;
close all;

%% Change DataSet

load('D:\ACGT-Net\IndianPine\Indian.mat');
load('D:\ACGT-Net\IndianPine\Indian_gt.mat');
load('D:\ACGT-Net\IndianPine\IndianPineFullClassMap.mat');

image=double(image);
image = image(:,:,[1:103, 109:149,164:219]);
GT=double(GT);
FullClassMap=IndianPineFullClassMap;

% load XiongAn2Cut
% load XiongAn2CutGT
% load XiongAn2FullClassMap
% 
% image=double(XiongAn2Cut);
% GT=double(XiongAn2CutGT);
% FullClassMap=XiongAn2FullClassMap;

%%

GT2d=hyperConvert2d(GT);
ClassTab=tabulate(GT2d);
[ClassSize,~]=size(ClassTab);
ClassSize=ClassSize-1;
save('D:\ACGT-Net\ProcessingData\ClassSize.mat','ClassSize');

%%

result=Processing(image,GT);

%%

load('D:/ACGT-Net/ProcessingData\sX.mat');

% image = paviaU;
% GT = paviaU_gt;

image = double(image);
[ind1]=find(GT>0);
com = double(FullClassMap);
com(ind1)=double(GT(ind1));
GT = com;
GT2d=hyperConvert2d(GT);

[hr,wr,bands]=size(image);
nall = hr*wr;
inde = 1:nall;
indexmatrix = reshape(inde,hr,wr);

GT2d(GT2d==0)=17;
CM = giveColorCM_HH(GT2d,hr,wr);
% figure;
% imshow(uint8(CM));

wopt=3;
nr=hr;
nsec=0.1012;

turns=fix(hr/20);
t_Mod=mod(hr,20);

[trainImages, trainLabels, trainIndexs] = trainsamples(image,GT,nsec,ClassSize);
[testImages, testLabels, testIndexs] = testsamples(image,GT,trainIndexs);
trainImages=trainImages/max(max(trainImages));
testImages=testImages/max(max(testImages));

TR=zeros(hr,wr);
TE=zeros(hr,wr);
TR(trainIndexs)=GT(trainIndexs);
TE(testIndexs)=GT(testIndexs);

save('D:\ACGT-Net\ProcessingData\TE.mat','TE');
save('D:\ACGT-Net\ProcessingData\TR.mat','TR');
save('D:\ACGT-Net\ProcessingData\trainIndexs.mat','trainIndexs');
save('D:\ACGT-Net\ProcessingData\testIndexs.mat','testIndexs');

I=double(image);

cs=sX;

[~,Feature_Size]=size(sX);
save('D:\ACGT-Net\ProcessingData\Feature_Size.mat','Feature_Size');

I = I(:,:,cs);
 [m, n, z] = size(I);
% % 

I2d = hyperConvert2d(I);
for i = 1 : z
    I2d(i,:) = mat2gray(I2d(i,:));
end
TR2d=zeros(1,m*n);
TE2d=zeros(1,m*n);
TR2d(1,trainIndexs(1,:))=trainLabels;
TE2d(1,:)=GT2d;

% 空间滤波
indexs=find(TR2d>0);
testIndexs=find(TE2d>0);
    nDim=z;
    ntrn=length(trainLabels(:,:));
    ntst=m*n;
    nAll=m*n;
    tempimg=I2d';
    data2=tempimg(:,:);
[ TR_Neighbor, TE_Neighbor]=neighborhood(wopt,nr,indexs,testIndexs,ntrn,ntst,nDim,nAll,data2);

TR_sample = I2d(:,TR2d>0);
TR_temp = TR2d(:,TR2d>0);
TR_Neighbor=TR_Neighbor*10;
TR_Neighbor=TR_Neighbor';

for i=1:turns


TE_sample = I2d(:,(i-1)*m*20+1:i*m*20);
    

TE_temp = TE2d(:,(i-1)*m*20+1:i*m*20);


TE_Neighbor_new=TE_Neighbor((i-1)*m*20+1:i*m*20,:)*10;

X = [TR_sample,TE_sample];
Y = [TR_temp, TE_temp];

% 制作空间滤波权输入项

TE_Neighbor_new=TE_Neighbor_new';

% %原图像权制作
K = 10;
si = 1;
Train_W = creatLap(TR_sample, K, si);
Train_D = (sum(Train_W, 2)).^(-1/2);
Train_D = diag(Train_D);
L_temp = Train_W * Train_D;
Train_L = Train_D * L_temp;
Train_L = Train_L + eye(size(Train_L));

Test_W = creatLap(TE_sample, K, si); 
Test_D = (sum(Test_W, 2)).^(-1/2);
Test_D = diag(Test_D);
L_temp = Test_W * Test_D;
Test_L = Test_D * L_temp;
Test_L = Test_L + eye(size(Test_L));

Train_X = TR_sample';
Test_X = TE_sample';
TrLabel = TR_temp';
TeLabel = TE_temp';

% 
% % 空间滤波权制作
Train_W_n = creatLap(TR_Neighbor, K, si);
Train_D_n = (sum(Train_W_n, 2)).^(-1/2);
Train_D_n = diag(Train_D_n);
L_temp_n = Train_W_n * Train_D_n;
Train_L_n = Train_D_n * L_temp_n;
Train_L_n = Train_L_n + eye(size(Train_L_n));

Test_W_n = creatLap(TE_Neighbor_new, K, si); 
Test_D_n = (sum(Test_W_n, 2)).^(-1/2);
Test_D_n = diag(Test_D_n);
L_temp_n = Test_W_n * Test_D_n;
Test_L_n = Test_D_n * L_temp_n;
Test_L_n = Test_L_n + eye(size(Test_L_n));

Train_X_n = TR_Neighbor';
Test_X_n = TE_Neighbor_new';
TrLabel_n = TR_temp';
TeLabel_n = TE_temp';

add=num2str(i);
%% Please replace the following route with your own one
save(['D:\ACGT-Net\HSI_GCN/Train_X',add,'.mat'],'Train_X');
save(['D:\ACGT-Net\HSI_GCN/Test_X',add,'.mat'],'Test_X');
save(['D:\ACGT-Net\HSI_GCN/TrLabel',add,'.mat'],'TrLabel');
save(['D:\ACGT-Net\HSI_GCN/TeLabel',add,'.mat'],'TeLabel');
save(['D:\ACGT-Net\HSI_GCN/Train_L',add,'.mat'],'Train_L');
save(['D:\ACGT-Net\HSI_GCN/Test_L',add,'.mat'],'Test_L');
save(['D:\ACGT-Net\HSI_GCN/Train_X_n',add,'.mat'],'Train_X_n');
save(['D:\ACGT-Net\HSI_GCN/Test_X_n',add,'.mat'],'Test_X_n');
save(['D:\ACGT-Net\HSI_GCN/TrLabel_n',add,'.mat'],'TrLabel_n');
save(['D:\ACGT-Net\HSI_GCN/TeLabel_n',add,'.mat'],'TeLabel_n');
save(['D:\ACGT-Net\HSI_GCN/Train_L_n',add,'.mat'],'Train_L_n');
save(['D:\ACGT-Net\HSI_GCN/Test_L_n',add,'.mat'],'Test_L_n');

save('D:\ACGT-Net\ProcessingData\turns(i)','i')

fprintf('%sth ClassCUt Finished\n',add);
end

%% 不可完全分割图像剩余部分

save('D:\ACGT-Net\ProcessingData\t_Mod.mat','t_Mod');

if t_Mod~=0
    
    TE_sample = I2d(:,m*i*20+1:length(testIndexs));
    TE_temp = TE2d(:,m*i*20+1:length(testIndexs));
    TE_Neighbor_new=TE_Neighbor(m*i*20+1:length(testIndexs),:)*10;

    X = [TR_sample,TE_sample];
    Y = [TR_temp, TE_temp];

    % 制作空间滤波权输入项

    TE_Neighbor_new=TE_Neighbor_new';

    % %原图像权制作
    K = 10;
    si = 1;
    Train_W = creatLap(TR_sample, K, si);
    Train_D = (sum(Train_W, 2)).^(-1/2);
    Train_D = diag(Train_D);
    L_temp = Train_W * Train_D;
    Train_L = Train_D * L_temp;
    Train_L = Train_L + eye(size(Train_L));

    Test_W = creatLap(TE_sample, K, si); 
    Test_D = (sum(Test_W, 2)).^(-1/2);
    Test_D = diag(Test_D);
    L_temp = Test_W * Test_D;
    Test_L = Test_D * L_temp;
    Test_L = Test_L + eye(size(Test_L));

    Train_X = TR_sample';
    Test_X = TE_sample';
    TrLabel = TR_temp';
    TeLabel = TE_temp';

    % 
    % % 空间滤波权制作
    Train_W_n = creatLap(TR_Neighbor, K, si);
    Train_D_n = (sum(Train_W_n, 2)).^(-1/2);
    Train_D_n = diag(Train_D_n);
    L_temp_n = Train_W_n * Train_D_n;
    Train_L_n = Train_D_n * L_temp_n;
    Train_L_n = Train_L_n + eye(size(Train_L_n));

    Test_W_n = creatLap(TE_Neighbor_new, K, si); 
    Test_D_n = (sum(Test_W_n, 2)).^(-1/2);
    Test_D_n = diag(Test_D_n);
    L_temp_n = Test_W_n * Test_D_n;
    Test_L_n = Test_D_n * L_temp_n;
    Test_L_n = Test_L_n + eye(size(Test_L_n));

    Train_X_n = TR_Neighbor';
    Test_X_n = TE_Neighbor_new';
    TrLabel_n = TR_temp';
    TeLabel_n = TE_temp';

    i=i+1;
    add=num2str(i);
    % Please replace the following route with your own one
    save(['D:\ACGT-Net\HSI_GCN/Train_X',add,'.mat'],'Train_X');
    save(['D:\ACGT-Net\HSI_GCN/Test_X',add,'.mat'],'Test_X');
    save(['D:\ACGT-Net\HSI_GCN/TrLabel',add,'.mat'],'TrLabel');
    save(['D:\ACGT-Net\HSI_GCN/TeLabel',add,'.mat'],'TeLabel');
    save(['D:\ACGT-Net\HSI_GCN/Train_L',add,'.mat'],'Train_L');
    save(['D:\ACGT-Net\HSI_GCN/Test_L',add,'.mat'],'Test_L');
    save(['D:\ACGT-Net\HSI_GCN/Train_X_n',add,'.mat'],'Train_X_n');
    save(['D:\ACGT-Net\HSI_GCN/Test_X_n',add,'.mat'],'Test_X_n');
    save(['D:\ACGT-Net\HSI_GCN/TrLabel_n',add,'.mat'],'TrLabel_n');
    save(['D:\ACGT-Net\HSI_GCN/TeLabel_n',add,'.mat'],'TeLabel_n');
    save(['D:\ACGT-Net\HSI_GCN/Train_L_n',add,'.mat'],'Train_L_n');
    save(['D:\ACGT-Net\HSI_GCN/Test_L_n',add,'.mat'],'Test_L_n');

    fprintf('%sth ClassCUt Finished\n',add);

    fprintf('Initial Outset Has Been Put\n');

    save('D:\ACGT-Net\ProcessingData\turns(i)','i')


end

%%

function [ XTrnm , XTstm]=neighborhood(wopt,nr,indexs,testIndexs,ntrn,ntst,nDim,nAll,data2)  %5,145,[1,1043],[9323,1],1043,9323,20,21025,[21025,20],27.0464
  w = wopt; wc = (w-1)/2;  vv = -wc : wc;
        idw0 = repmat(vv*nr,w,1) + repmat(vv',1,w);
        idw0 = reshape(idw0,1,w*w);          %[1,25]
        XTrnm   = zeros(ntrn, nDim);         %[1043,200]
        XTstm   = zeros(ntst, nDim);         %[9323,200]
        for i = 1 : ntrn                     %1:1043
            idw = idw0 + indexs(i); idw = [indexs(i) idw]; idw((w^2+1)/2+1)=[];
            idw(idw>nAll | idw<1) = [];      %idw中存放的是indexs[i]周围的元素的地址 
         
            Xtmp = data2(idw,:);            %[25,20]
             XTrnm(i,:)   = mean(Xtmp,1);   %把Xtmp的每一列取平均值 得到一行20列的数组复制给XTrnm(i,:) 得到了训练样本的周围元素的均值
        end
       
        for i = 1 : ntst                    %1：9323
            idw = idw0 + testIndexs(i); idw = [testIndexs(i) idw]; idw((w^2+1)/2+1)=[];
            idw(idw>nAll | idw<1) = [];     %idw中存放的是测试样本周围的元素的地址 
           
            Xtmp = data2(idw,:); 
              XTstm(i,:)   = mean(Xtmp,1); %得到了测试样本的周围元素的均值[1,20]
           
        end
        XTrnm= XTrnm./10;        
         XTstm= XTstm./10;        
%         XTrnm= XTrnm./9604;         
%          XTstm= XTstm./9604;       
%         XTrnmL2 = XTrnm./ repmat(sqrt(sum(XTrnm.*XTrnm,2)),[1 nDim]); % L2 norm 
%         XTstmL2 = XTstm./ repmat(sqrt(sum(XTstm.*XTstm,2)),[1 nDim]); % L2 norm
end

function [M] = hyperConvert2d(M)
% HYPERCONVERT2D Converts an HSI cube to a 2D matrix
% Converts a 3D HSI cube (m x n x p) to a 2D matrix of points (p X N)
% where N = mn
%
% Usage
%   [M] = hyperConvert2d(M)
% Inputs
%   M - 3D HSI cube (m x n x p)
% Outputs
%   M - 2D data matrix (p x N)

if (ndims(M)>3 || ndims(M)<2)
    error('Input image must be m x n x p or m x n');
end
if (ndims(M) == 2)
    numBands = 1;
    [h, w] = size(M);
else
    [h, w, numBands] = size(M);
end

M = reshape(M, w*h, numBands).';

end

function [W, D, L]=creatLap(X,k,sigma) 
      X=X';
      options = [];
      options.NeighborMode = 'KNN';
      options.k = k;
      options.WeightMode = 'HeatKernel';
      options.t = sigma;

      W = (constructW(X, options));
      D = (diag(sum(W, 2)));
      L = D - W;
end

function D = EuDist2(fea_a,fea_b,bSqrt)
%EUDIST2 Efficiently Compute the Euclidean Distance Matrix by Exploring the
%Matlab matrix operations.
%
%   D = EuDist(fea_a,fea_b)
%   fea_a:    nSample_a * nFeature
%   fea_b:    nSample_b * nFeature
%   D:      nSample_a * nSample_a
%       or  nSample_a * nSample_b
%
%    Examples:
%
%       a = rand(500,10);
%       b = rand(1000,10);
%
%       A = EuDist2(a); % A: 500*500
%       D = EuDist2(a,b); % D: 500*1000
%
%   version 2.1 --November/2011
%   version 2.0 --May/2009
%   version 1.0 --November/2005
%
%   Written by Deng Cai (dengcai AT gmail.com)


if ~exist('bSqrt','var')
    bSqrt = 1;
end

if (~exist('fea_b','var')) || isempty(fea_b)
    aa = sum(fea_a.*fea_a,2);
    ab = fea_a*fea_a';
    
    if issparse(aa)
        aa = full(aa);
    end
    
    D = bsxfun(@plus,aa,aa') - 2*ab;
    D(D<0) = 0;
    if bSqrt
        D = sqrt(D);
    end
    D = max(D,D');
else
    aa = sum(fea_a.*fea_a,2);
    bb = sum(fea_b.*fea_b,2);
    ab = fea_a*fea_b';

    if issparse(aa)
        aa = full(aa);
        bb = full(bb);
    end

    D = bsxfun(@plus,aa,bb') - 2*ab;
    D(D<0) = 0;
    if bSqrt
        D = sqrt(D);
    end
end
end

function W = constructW(fea,options)
%	Usage:
%	W = constructW(fea,options)
%
%	fea: Rows of vectors of data points. Each row is x_i
%   options: Struct value in Matlab. The fields in options that can be set:
%                  
%           NeighborMode -  Indicates how to construct the graph. Choices
%                           are: [Default 'KNN']
%                'KNN'            -  k = 0
%                                       Complete graph
%                                    k > 0
%                                      Put an edge between two nodes if and
%                                      only if they are among the k nearst
%                                      neighbors of each other. You are
%                                      required to provide the parameter k in
%                                      the options. Default k=5.
%               'Supervised'      -  k = 0
%                                       Put an edge between two nodes if and
%                                       only if they belong to same class. 
%                                    k > 0
%                                       Put an edge between two nodes if
%                                       they belong to same class and they
%                                       are among the k nearst neighbors of
%                                       each other. 
%                                    Default: k=0
%                                   You are required to provide the label
%                                   information gnd in the options.
%                                              
%           WeightMode   -  Indicates how to assign weights for each edge
%                           in the graph. Choices are:
%               'Binary'       - 0-1 weighting. Every edge receiveds weight
%                                of 1. 
%               'HeatKernel'   - If nodes i and j are connected, put weight
%                                W_ij = exp(-norm(x_i - x_j)/2t^2). You are 
%                                required to provide the parameter t. [Default One]
%               'Cosine'       - If nodes i and j are connected, put weight
%                                cosine(x_i,x_j). 
%               
%            k         -   The parameter needed under 'KNN' NeighborMode.
%                          Default will be 5.
%            gnd       -   The parameter needed under 'Supervised'
%                          NeighborMode.  Colunm vector of the label
%                          information for each data point.
%            bLDA      -   0 or 1. Only effective under 'Supervised'
%                          NeighborMode. If 1, the graph will be constructed
%                          to make LPP exactly same as LDA. Default will be
%                          0. 
%            t         -   The parameter needed under 'HeatKernel'
%                          WeightMode. Default will be 1
%         bNormalized  -   0 or 1. Only effective under 'Cosine' WeightMode.
%                          Indicates whether the fea are already be
%                          normalized to 1. Default will be 0
%      bSelfConnected  -   0 or 1. Indicates whether W(i,i) == 1. Default 0
%                          if 'Supervised' NeighborMode & bLDA == 1,
%                          bSelfConnected will always be 1. Default 0.
%            bTrueKNN  -   0 or 1. If 1, will construct a truly kNN graph
%                          (Not symmetric!). Default will be 0. Only valid
%                          for 'KNN' NeighborMode
%
%
%    Examples:
%
%       fea = rand(50,15);
%       options = [];
%       options.NeighborMode = 'KNN';
%       options.k = 5;
%       options.WeightMode = 'HeatKernel';
%       options.t = 1;
%       W = constructW(fea,options);
%       
%       
%       fea = rand(50,15);
%       gnd = [ones(10,1);ones(15,1)*2;ones(10,1)*3;ones(15,1)*4];
%       options = [];
%       options.NeighborMode = 'Supervised';
%       options.gnd = gnd;
%       options.WeightMode = 'HeatKernel';
%       options.t = 1;
%       W = constructW(fea,options);
%       
%       
%       fea = rand(50,15);
%       gnd = [ones(10,1);ones(15,1)*2;ones(10,1)*3;ones(15,1)*4];
%       options = [];
%       options.NeighborMode = 'Supervised';
%       options.gnd = gnd;
%       options.bLDA = 1;
%       W = constructW(fea,options);      
%       
%
%    For more details about the different ways to construct the W, please
%    refer:
%       Deng Cai, Xiaofei He and Jiawei Han, "Document Clustering Using
%       Locality Preserving Indexing" IEEE TKDE, Dec. 2005.
%    
%
%    Written by Deng Cai (dengcai2 AT cs.uiuc.edu), April/2004, Feb/2006,
%                                             May/2007
% 
% fea=normlizedW(fea',0);
% fea=fea';
bSpeed  = 1;

if (~exist('options','var'))
   options = [];
end

if isfield(options,'Metric')
    warning('This function has been changed and the Metric is no longer be supported');
end


if ~isfield(options,'bNormalized')
    options.bNormalized = 0;
end

%=================================================
if ~isfield(options,'NeighborMode')
    options.NeighborMode = 'KNN';
end

switch lower(options.NeighborMode)
    case {lower('KNN')}  %For simplicity, we include the data point itself in the kNN
        if ~isfield(options,'k')
            options.k = 5;
        end
    case {lower('Supervised')}
        if ~isfield(options,'bLDA')
            options.bLDA = 0;
        end
        if options.bLDA
            options.bSelfConnected = 1;
        end
        if ~isfield(options,'k')
            options.k = 0;
        end
        if ~isfield(options,'gnd')
            error('Label(gnd) should be provided under ''Supervised'' NeighborMode!');
        end
        if ~isempty(fea) && length(options.gnd) ~= size(fea,1)
            error('gnd doesn''t match with fea!');
        end
    otherwise
        error('NeighborMode does not exist!');
end

%=================================================

if ~isfield(options,'WeightMode')
    options.WeightMode = 'HeatKernel';
end

bBinary = 0;
bCosine = 0;
switch lower(options.WeightMode)
    case {lower('Binary')}
        bBinary = 1; 
    case {lower('HeatKernel')}
        if ~isfield(options,'t')
            nSmp = size(fea,1);
            if nSmp > 3000
                D = EuDist2(fea(randsample(nSmp,3000),:));
            else
                D = EuDist2(fea);
            end
            options.t = mean(mean(D));
        end
    case {lower('Cosine')}
        bCosine = 1;
    otherwise
        error('WeightMode does not exist!');
end

%=================================================

if ~isfield(options,'bSelfConnected')
    options.bSelfConnected = 0;
end

%=================================================

if isfield(options,'gnd') 
    nSmp = length(options.gnd);
else
    nSmp = size(fea,1);
end
maxM = 62500000; %500M
BlockSize = floor(maxM/(nSmp*3));


if strcmpi(options.NeighborMode,'Supervised')
    Label = unique(options.gnd);
    nLabel = length(Label);
    if options.bLDA
        G = zeros(nSmp,nSmp);
        for idx=1:nLabel
            classIdx = options.gnd==Label(idx);
            G(classIdx,classIdx) = 1/sum(classIdx);
        end
        W = sparse(G);
        return;
    end
    
    switch lower(options.WeightMode)
        case {lower('Binary')}
            if options.k > 0
                G = zeros(nSmp*(options.k+1),3);
                idNow = 0;
                for i=1:nLabel
                    classIdx = find(options.gnd==Label(i));
                    D = EuDist2(fea(classIdx,:),[],0);
                    [dump idx] = sort(D,2); % sort each row
                    clear D dump;
                    idx = idx(:,1:options.k+1);
                    
                    nSmpClass = length(classIdx)*(options.k+1);
                    G(idNow+1:nSmpClass+idNow,1) = repmat(classIdx,[options.k+1,1]);
                    G(idNow+1:nSmpClass+idNow,2) = classIdx(idx(:));
                    G(idNow+1:nSmpClass+idNow,3) = 1;
                    idNow = idNow+nSmpClass;
                    clear idx
                end
                G = sparse(G(:,1),G(:,2),G(:,3),nSmp,nSmp);
                G = max(G,G');
            else
                G = zeros(nSmp,nSmp);
                for i=1:nLabel
                    classIdx = find(options.gnd==Label(i));
                    G(classIdx,classIdx) = 1;
                end
            end
            
            if ~options.bSelfConnected
                for i=1:size(G,1)
                    G(i,i) = 0;
                end
            end
            
            W = sparse(G);
        case {lower('HeatKernel')}
            if options.k > 0
                G = zeros(nSmp*(options.k+1),3);
                idNow = 0;
                for i=1:nLabel
                    classIdx = find(options.gnd==Label(i));
                    D = EuDist2(fea(classIdx,:),[],0);
                    [dump idx] = sort(D,2); % sort each row
                    clear D;
                    idx = idx(:,1:options.k+1);
                    dump = dump(:,1:options.k+1);
                    dump = exp(-dump/(2*options.t^2));
                    
                    nSmpClass = length(classIdx)*(options.k+1);
                    G(idNow+1:nSmpClass+idNow,1) = repmat(classIdx,[options.k+1,1]);
                    G(idNow+1:nSmpClass+idNow,2) = classIdx(idx(:));
                    G(idNow+1:nSmpClass+idNow,3) = dump(:);
                    idNow = idNow+nSmpClass;
                    clear dump idx
                end
                G = sparse(G(:,1),G(:,2),G(:,3),nSmp,nSmp);
            else
                G = zeros(nSmp,nSmp);
                for i=1:nLabel
                    classIdx = find(options.gnd==Label(i));
                    D = EuDist2(fea(classIdx,:),[],0);
                    D = exp(-D/(2*options.t^2));
                    G(classIdx,classIdx) = D;
                end
            end
            
            if ~options.bSelfConnected
                for i=1:size(G,1)
                    G(i,i) = 0;
                end
            end

            W = sparse(max(G,G'));
        case {lower('Cosine')}
            if ~options.bNormalized
                fea = NormalizeFea(fea);
            end

            if options.k > 0
                G = zeros(nSmp*(options.k+1),3);
                idNow = 0;
                for i=1:nLabel
                    classIdx = find(options.gnd==Label(i));
                    D = fea(classIdx,:)*fea(classIdx,:)';
                    [dump idx] = sort(-D,2); % sort each row
                    clear D;
                    idx = idx(:,1:options.k+1);
                    dump = -dump(:,1:options.k+1);
                    
                    nSmpClass = length(classIdx)*(options.k+1);
                    G(idNow+1:nSmpClass+idNow,1) = repmat(classIdx,[options.k+1,1]);
                    G(idNow+1:nSmpClass+idNow,2) = classIdx(idx(:));
                    G(idNow+1:nSmpClass+idNow,3) = dump(:);
                    idNow = idNow+nSmpClass;
                    clear dump idx
                end
                G = sparse(G(:,1),G(:,2),G(:,3),nSmp,nSmp);
            else
                G = zeros(nSmp,nSmp);
                for i=1:nLabel
                    classIdx = find(options.gnd==Label(i));
                    G(classIdx,classIdx) = fea(classIdx,:)*fea(classIdx,:)';
                end
            end

            if ~options.bSelfConnected
                for i=1:size(G,1)
                    G(i,i) = 0;
                end
            end

            W = sparse(max(G,G'));
        otherwise
            error('WeightMode does not exist!');
    end
    return;
end


if bCosine && ~options.bNormalized
    Normfea = NormalizeFea(fea);
end

if strcmpi(options.NeighborMode,'KNN') && (options.k > 0)
    if ~(bCosine && options.bNormalized)
        G = zeros(nSmp*(options.k+1),3);
        for i = 1:ceil(nSmp/BlockSize)
            if i == ceil(nSmp/BlockSize)
                smpIdx = (i-1)*BlockSize+1:nSmp;
                dist = EuDist2(fea(smpIdx,:),fea,0);
                if bSpeed
                    nSmpNow = length(smpIdx);
                    dump = zeros(nSmpNow,options.k+1);
                    idx = dump;
                    for j = 1:options.k+1
                        [dump(:,j),idx(:,j)] = min(dist,[],2);
                        temp = (idx(:,j)-1)*nSmpNow+[1:nSmpNow]';
                        dist(temp) = 1e100;
                    end
                else
                    [dump idx] = sort(dist,2); % sort each row
                    idx = idx(:,1:options.k+1);
                    dump = dump(:,1:options.k+1);
                end
                
                if ~bBinary
                    if bCosine
                        dist = Normfea(smpIdx,:)*Normfea';
                        dist = full(dist);
                        linidx = [1:size(idx,1)]';
                        dump = dist(sub2ind(size(dist),linidx(:,ones(1,size(idx,2))),idx));
                    else
                        dump = exp(-dump/(2*options.t^2));
                    end
                end
                
                G((i-1)*BlockSize*(options.k+1)+1:nSmp*(options.k+1),1) = repmat(smpIdx',[options.k+1,1]);
                G((i-1)*BlockSize*(options.k+1)+1:nSmp*(options.k+1),2) = idx(:);
                if ~bBinary
                    G((i-1)*BlockSize*(options.k+1)+1:nSmp*(options.k+1),3) = dump(:);
                else
                    G((i-1)*BlockSize*(options.k+1)+1:nSmp*(options.k+1),3) = 1;
                end
            else
                smpIdx = (i-1)*BlockSize+1:i*BlockSize;
            
                dist = EuDist2(fea(smpIdx,:),fea,0);
                
                if bSpeed
                    nSmpNow = length(smpIdx);
                    dump = zeros(nSmpNow,options.k+1);
                    idx = dump;
                    for j = 1:options.k+1
                        [dump(:,j),idx(:,j)] = min(dist,[],2);
                        temp = (idx(:,j)-1)*nSmpNow+[1:nSmpNow]';
                        dist(temp) = 1e100;
                    end
                else
                    [dump idx] = sort(dist,2); % sort each row
                    idx = idx(:,1:options.k+1);
                    dump = dump(:,1:options.k+1);
                end
                
                if ~bBinary
                    if bCosine
                        dist = Normfea(smpIdx,:)*Normfea';
                        dist = full(dist);
                        linidx = [1:size(idx,1)]';
                        dump = dist(sub2ind(size(dist),linidx(:,ones(1,size(idx,2))),idx));
                    else
                        dump = exp(-dump/(2*options.t^2));
                    end
                end
                
                G((i-1)*BlockSize*(options.k+1)+1:i*BlockSize*(options.k+1),1) = repmat(smpIdx',[options.k+1,1]);
                G((i-1)*BlockSize*(options.k+1)+1:i*BlockSize*(options.k+1),2) = idx(:);
                if ~bBinary
                    G((i-1)*BlockSize*(options.k+1)+1:i*BlockSize*(options.k+1),3) = dump(:);
                else
                    G((i-1)*BlockSize*(options.k+1)+1:i*BlockSize*(options.k+1),3) = 1;
                end
            end
        end

        W = sparse(G(:,1),G(:,2),G(:,3),nSmp,nSmp);
    else
        G = zeros(nSmp*(options.k+1),3);
        for i = 1:ceil(nSmp/BlockSize)
            if i == ceil(nSmp/BlockSize)
                smpIdx = (i-1)*BlockSize+1:nSmp;
                dist = fea(smpIdx,:)*fea';
                dist = full(dist);
                if bSpeed
                    nSmpNow = length(smpIdx);
                    dump = zeros(nSmpNow,options.k+1);
                    idx = dump;
                    for j = 1:options.k+1
                        [dump(:,j),idx(:,j)] = max(dist,[],2);
                        temp = (idx(:,j)-1)*nSmpNow+[1:nSmpNow]';
                        dist(temp) = 0;
                    end
                else
                    [dump idx] = sort(-dist,2); % sort each row
                    idx = idx(:,1:options.k+1);
                    dump = -dump(:,1:options.k+1);
                end

                G((i-1)*BlockSize*(options.k+1)+1:nSmp*(options.k+1),1) = repmat(smpIdx',[options.k+1,1]);
                G((i-1)*BlockSize*(options.k+1)+1:nSmp*(options.k+1),2) = idx(:);
                G((i-1)*BlockSize*(options.k+1)+1:nSmp*(options.k+1),3) = dump(:);
            else
                smpIdx = (i-1)*BlockSize+1:i*BlockSize;
                dist = fea(smpIdx,:)*fea';
                dist = full(dist);
                
                if bSpeed
                    nSmpNow = length(smpIdx);
                    dump = zeros(nSmpNow,options.k+1);
                    idx = dump;
                    for j = 1:options.k+1
                        [dump(:,j),idx(:,j)] = max(dist,[],2);
                        temp = (idx(:,j)-1)*nSmpNow+[1:nSmpNow]';
                        dist(temp) = 0;
                    end
                else
                    [dump idx] = sort(-dist,2); % sort each row
                    idx = idx(:,1:options.k+1);
                    dump = -dump(:,1:options.k+1);
                end

                G((i-1)*BlockSize*(options.k+1)+1:i*BlockSize*(options.k+1),1) = repmat(smpIdx',[options.k+1,1]);
                G((i-1)*BlockSize*(options.k+1)+1:i*BlockSize*(options.k+1),2) = idx(:);
                G((i-1)*BlockSize*(options.k+1)+1:i*BlockSize*(options.k+1),3) = dump(:);
            end
        end

        W = sparse(G(:,1),G(:,2),G(:,3),nSmp,nSmp);
    end
    
    if bBinary
        W(logical(W)) = 1;
    end
    
    if isfield(options,'bSemiSupervised') && options.bSemiSupervised
        tmpgnd = options.gnd(options.semiSplit);
        
        Label = unique(tmpgnd);
        nLabel = length(Label);
        G = zeros(sum(options.semiSplit),sum(options.semiSplit));
        for idx=1:nLabel
            classIdx = tmpgnd==Label(idx);
            G(classIdx,classIdx) = 1;
        end
        Wsup = sparse(G);
        if ~isfield(options,'SameCategoryWeight')
            options.SameCategoryWeight = 1;
        end
        W(options.semiSplit,options.semiSplit) = (Wsup>0)*options.SameCategoryWeight;
    end
    
    if ~options.bSelfConnected
        W = W - diag(diag(W));
    end

    if isfield(options,'bTrueKNN') && options.bTrueKNN
        
    else
        W = max(W,W');
    end
    
    return;
end
end

function classification_map_rgb=giveColorCM_HH(classTest,m,n)
colorList = [0, 205, 0;
    127, 255, 0; 
    46, 139, 87; 
    0, 139, 0; 
    160, 82, 45; 
    0, 255, 255;
    255, 255, 255; 
    216, 191, 216; 
    255, 0, 0; 
    139, 0, 0; 
    0, 100, 255;
    255, 255, 0; 
    238, 154, 0; 
    85, 26, 139;
    255, 127, 80;
    0,0,205; 
    0,0,0;
    0,0,0;
    0,0,0;
    0,0,0;
    0,0,0;
    0,0,0;
    0,0,0;
    0,0,0;
    0,0,0;
    0,0,0];
classification_map_rgb = reshape(colorList(classTest,:),m,n,[]);
end

function [images, labels, indexs] = trainsamples(img, gt,nsec,ClassSize)
% 生成实验1的训练样本
indexs = [];
% labels = [];
a=zeros(ClassSize,1);
for j=1:ClassSize
    a(j)=length(find(gt==j));
end
for i = 1 : ClassSize
%      nuse = min(nsec, round(a(i)/2) ); 
      nuse = ceil(a(i)*nsec);
    switch i
%         case 1
%             tempindex = find(gt == 1);
%             tempindex=tempindex';                          %tempindex是列向量
%             rp=randperm(length(tempindex));                %不重复的随机打乱1-length（tempindex）
%             indexs=[indexs tempindex(rp(1: 548))];           %随机选6个类是1的地址赋值给indexs
%         case 2
%             tempindex = find(gt == 2);
%             tempindex=tempindex';
%             rp=randperm(length(tempindex));
%             indexs=[indexs tempindex(rp(1:540))];
%         case 3
%             tempindex = find(gt == 3);
%             tempindex=tempindex';
%             rp=randperm(length(tempindex));
%             indexs=[indexs tempindex(rp(1: 392))];
%         case 4
%             tempindex = find(gt == 4);
%             tempindex=tempindex';
%             rp=randperm(length(tempindex));
%             indexs=[indexs tempindex(rp(1: 542))];
%         case 5
%             tempindex = find(gt == 5);
%             tempindex=tempindex';
%             rp=randperm(length(tempindex));
%             indexs=[indexs tempindex(rp(1: 265))];
%         case 6
%             tempindex = find(gt == 6);
%             tempindex=tempindex';
%             rp=randperm(length(tempindex));
%             indexs=[indexs tempindex(rp(1: 532))];
%         case 7
%             tempindex = find(gt == 7);
%             tempindex=tempindex';
%             rp=randperm(length(tempindex));
%             indexs=[indexs tempindex(rp(1: 375))];
%         case 8
%             tempindex = find(gt == 8);
%             tempindex=tempindex';
%             rp=randperm(length(tempindex));
%             indexs=[indexs tempindex(rp(1: 514))];
%         case 9
%             tempindex = find(gt == 9);
%             tempindex=tempindex';
%             rp=randperm(length(tempindex));
%              indexs=[indexs tempindex(rp(1: 231))];

        case 1
            tempindex = find(gt == 1);
            tempindex=tempindex';
            rp=randperm(length(tempindex));
             indexs=[indexs tempindex(rp(1: nuse))];
        case 2
            tempindex = find(gt == 2);
            tempindex=tempindex';
            rp=randperm(length(tempindex));
             indexs=[indexs tempindex(rp(1: nuse))];
        case 3
            tempindex = find(gt == 3);
            tempindex=tempindex';
            rp=randperm(length(tempindex));
             indexs=[indexs tempindex(rp(1: nuse))];
         case 4
            tempindex = find(gt == 4);
            tempindex=tempindex';
            rp=randperm(length(tempindex));
             indexs=[indexs tempindex(rp(1: nuse))];
        case 5
            tempindex = find(gt == 5);
            tempindex=tempindex';
            rp=randperm(length(tempindex));
             indexs=[indexs tempindex(rp(1: nuse))];
        case 6
            tempindex = find(gt == 6);
            tempindex=tempindex';
            rp=randperm(length(tempindex));
             indexs=[indexs tempindex(rp(1: nuse))];
        case 7
            tempindex = find(gt == 7);
            tempindex=tempindex';
            rp=randperm(length(tempindex));
             indexs=[indexs tempindex(rp(1: nuse))];
         case 8
            tempindex = find(gt == 8);
            tempindex=tempindex';
            rp=randperm(length(tempindex));
             indexs=[indexs tempindex(rp(1: nuse))];
         case 9
            tempindex = find(gt == 9);
            tempindex=tempindex';
            rp=randperm(length(tempindex));
             indexs=[indexs tempindex(rp(1: nuse))];
        case 10
            tempindex = find(gt == 10);
            tempindex=tempindex';
            rp=randperm(length(tempindex));
             indexs=[indexs tempindex(rp(1: nuse))];
        case 11
            tempindex = find(gt == 11);
            tempindex=tempindex';
            rp=randperm(length(tempindex));
             indexs=[indexs tempindex(rp(1: nuse))];
        case 12
            tempindex = find(gt == 12);
            tempindex=tempindex';
            rp=randperm(length(tempindex));
             indexs=[indexs tempindex(rp(1: nuse))];
         case 13
            tempindex = find(gt == 13);
            tempindex=tempindex';
            rp=randperm(length(tempindex));
             indexs=[indexs tempindex(rp(1: nuse))];
          case 14
            tempindex = find(gt == 14);
            tempindex=tempindex';
            rp=randperm(length(tempindex));
             indexs=[indexs tempindex(rp(1: nuse))];
          case 15
            tempindex = find(gt == 15);
            tempindex=tempindex';
            rp=randperm(length(tempindex));
             indexs=[indexs tempindex(rp(1: nuse))];
          case 16
            tempindex = find(gt == 16);
            tempindex=tempindex';
            rp=randperm(length(tempindex));
             indexs=[indexs tempindex(rp(1: nuse))];    
%         case 1
%             tempindex = find(gt == 1);
%             tempindex=tempindex';                          %tempindex是列向量
%             rp=randperm(length(tempindex));                %不重复的随机打乱1-length（tempindex）
%              indexs=[indexs tempindex(rp(1:6))];           %随机选6个类是1的地址赋值给indexs
%         case 2
%             tempindex = find(gt == 2);
%             tempindex=tempindex';
%             rp=randperm(length(tempindex));
%             indexs=[indexs tempindex(rp(1:144))];
%         case 3
%             tempindex = find(gt == 3);
%             tempindex=tempindex';
%             rp=randperm(length(tempindex));
%             indexs=[indexs tempindex(rp(1:84))];
%         case 4
%             tempindex = find(gt == 4);
%             tempindex=tempindex';
%             rp=randperm(length(tempindex));
%             indexs=[indexs tempindex(rp(1:24))];
%         case 5
%             tempindex = find(gt == 5);
%             tempindex=tempindex';
%             rp=randperm(length(tempindex));
%             indexs=[indexs tempindex(rp(1:50))];
%         case 6
%             tempindex = find(gt == 6);
%             tempindex=tempindex';
%             rp=randperm(length(tempindex));
%             indexs=[indexs tempindex(rp(1:75))];
%         case 7
%             tempindex = find(gt == 7);
%             tempindex=tempindex';
%             rp=randperm(length(tempindex));
%             indexs=[indexs tempindex(rp(1:3))];
%         case 8
%             tempindex = find(gt == 8);
%             tempindex=tempindex';
%             rp=randperm(length(tempindex));
%             indexs=[indexs tempindex(rp(1:49))];
%         case 9
%             tempindex = find(gt == 9);
%             tempindex=tempindex';
%             rp=randperm(length(tempindex));
%              indexs=[indexs tempindex(rp(1:2))];
%         case 10
%             tempindex = find(gt == 10);
%             tempindex=tempindex';
%             rp=randperm(length(tempindex));
%              indexs=[indexs tempindex(rp(1:97))];
%         case 11
%             tempindex = find(gt == 11);
%             tempindex=tempindex';
%             rp=randperm(length(tempindex));
%              indexs=[indexs tempindex(rp(1:247))];
%         case 12
%             tempindex = find(gt == 12);
%             tempindex=tempindex';
%             rp=randperm(length(tempindex));
%              indexs=[indexs tempindex(rp(1:62))];
%          case 13
%             tempindex = find(gt == 13);
%             tempindex=tempindex';
%             rp=randperm(length(tempindex));
%              indexs=[indexs tempindex(rp(1:22))];
%           case 14
%             tempindex = find(gt == 14);
%             tempindex=tempindex';
%             rp=randperm(length(tempindex));
%              indexs=[indexs tempindex(rp(1:130))];
%           case 15
%             tempindex = find(gt == 15);
%             tempindex=tempindex';
%             rp=randperm(length(tempindex));
%              indexs=[indexs tempindex(rp(1:38))];
%           case 16
%             tempindex = find(gt == 16);
%             tempindex=tempindex';
%             rp=randperm(length(tempindex));
%              indexs=[indexs tempindex(rp(1:10))];    
    end
end



labels = gt(indexs);
labels = double(labels);

[nr,nc,ndim]=size(img);
nall=nr*nc;
tempimg=reshape(img,nall,ndim);       
% bandmaxvalue=max(tempimg(:));                           %样本（21025*200）的最大值
images = (tempimg(indexs, :))';                         %筛选样本得到一个1043*200的训练样本       

             %将训练样本转置再除以最大值，得到（0-1）的200*1043训练样本
%         images1= images./ repmat(sqrt(sum(images.*images,2)),[1 200]); 
%         images2=images1';


end

function [images, labels, indexs,tempimg,maxmun] = testsamples(img, gt,trainindexs)
% 生成实验1的测试样本
imgsize = size(img);
num = imgsize(1)*imgsize(2);     %20245
indexs = [];
gt(trainindexs)=0;             %gt145*145

for i = 1 : num                  %1:20245
    if gt(i) ~= 0
        indexs = [indexs; i];      %把类不是0的地址存进indexs
    end
end

labels = gt(indexs);
[nr,nc,ndim]=size(img);
nall=nr*nc;
tempimg = reshape(img, nall,ndim);
maxmun=max(tempimg(:));
images = tempimg(indexs,:);
images = double(images'./65517);
%  images1 = images./ repmat(sqrt(sum(images.*images,2)),[1 200]);
%  images2=images1';
end
