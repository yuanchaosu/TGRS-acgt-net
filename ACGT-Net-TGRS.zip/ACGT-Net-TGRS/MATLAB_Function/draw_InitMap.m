clc;
clear all;
close;

%draw ground truth
% load('D:/ACGT-Net/DrawTE.mat');
% load('D:/ACGT-Net/DrawTR.mat');

load('D:\ACGT-Net\IndianPine\Indian_gt.mat');
GT=GT;

load('D:/ACGT-Net/ProcessingData\TE.mat');
load('D:/ACGT-Net/ProcessingData\TR.mat');
[m, n] = size(TR);

%%

%XiongAnCut2的1%样本数量为1368,3%样本数量为4095,5%样本数量为6824，裁剪影像像元数7400

%%

GT2d = hyperConvert2d(GT);
GT2d(GT2d==0)=17;

% GT2d(GT2d~=2)=17;

% CM = giveColorCM_HH(GT2d,m,n);

%%

load('D:/ACGT-Net/ProcessingData\TE.mat');
load('D:/ACGT-Net/ProcessingData\TR.mat');

%% 文件读取阶段%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% mini-GCN

load('D:/ACGT-Net/ProcessingData\turns(i).mat');
turns=i;

% draw predicted classificaiton map
for i=1:turns
    strfile=["D:\ACGT-Net\features\features",num2str(i),".mat"];
    feature=strcat(strfile(1,1),strfile(1,2),strfile(1,3));
    load(feature);
    strfile_n=["D:\ACGT-Net\features\features_n",num2str(i),".mat"];
    feature_n=strcat(strfile_n(1,1),strfile_n(1,2),strfile_n(1,3));
    load(feature_n);
end

%% 图像拼接阶段%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% mini-GCN

load('D:/ACGT-Net/ProcessingData\t_Mod.mat');
if t_Mod~=0
    turns=turns-1;
end

for i=1:turns
    currentfeature=strcat("features",num2str(i));
    CFeature=eval(currentfeature);
    currentfeature_n=strcat("features_n",num2str(i));
    CFeature_n=eval(currentfeature_n);
    feature_combine=0.5*CFeature+0.5*CFeature_n;
    [~, ind] = max(feature_combine', [], 1);
    ind3d=hyperConvert3d(ind,m,20);
    feature_map=hyperConvert3d(feature_combine',m,20);
    map(1:m,(i-1)*20+1:i*20)=ind3d(1:m,1:20);
    map_feature(1:m,(i-1)*20+1:i*20,:)=feature_map(1:m,1:20,:);
end

if t_Mod~=0
    i=i+1;
    currentfeature=strcat("features",num2str(i));
    CFeature=eval(currentfeature);
    currentfeature_n=strcat("features_n",num2str(i));
    CFeature_n=eval(currentfeature_n);
    feature_combine=0.5*CFeature+0.5*CFeature_n;
    [~, ind] = max(feature_combine', [], 1);
    ind3d=hyperConvert3d(ind,m,t_Mod);
    feature_map=hyperConvert3d(feature_combine',m,t_Mod);
    map(1:m,(i-1)*20+1:(i-1)*20+t_Mod)=ind3d(1:m,1:t_Mod);
    map_feature(1:m,(i-1)*20+1:(i-1)*20+t_Mod,:)=feature_map(1:m,1:t_Mod,:);
end

%% 图像显示阶段%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% mini-GCN及1DCNN

map_feature2d=hyperConvert2d(map_feature);

[~,feature_max]=max(map_feature2d,[],1);
feature_map=hyperConvert3d(feature_max,m,n);

%% 

save('D:/ACGT-Net/ProcessingData\feature_map.mat','feature_map');

fprintf('GCN Has Finished\n');

%%


function [M] = hyperConvert2d(M)
% HYPERCONVERT2D Converts an HSI cube to a 2D matrix
% Converts a 3D HSI cube (m x n x p) to a 2D matrix of points (p X N)
% where N = mn
%
% Usage
%   [M] = hyperConvert2d(M)
% Inputs
%   M - 3D HSI cube (m x n x p)
% Outputs
%   M - 2D data matrix (p x N)

if (ndims(M)>3 || ndims(M)<2)
    error('Input image must be m x n x p or m x n');
end
if (ndims(M) == 2)
    numBands = 1;
    [h, w] = size(M);
else
    [h, w, numBands] = size(M);
end

M = reshape(M, w*h, numBands).';

end





function [img] = hyperConvert3d(img, h, w, numBands)
% HYPERCONVERT2D Converts an 2D matrix to a 3D data cube
% Converts a 2D matrix (p x N) to a 3D data cube (m x n x p)
% where N = m * n
% 
% Usage
%   [M] = hyperConvert3d(M)
% Inputs
%   M - 2D data matrix (p x N)
% Outputs
%   M - 3D data cube (m x n x p)


if (ndims(img) ~= 2)
    error('Input image must be p x N.');
end

[numBands, N] = size(img);

if (1 == N)
    img = reshape(img, h, w);
else
    img = reshape(img.', h, w, numBands); 
end

end





