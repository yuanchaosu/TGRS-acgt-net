clc;
clear all;
close;

load Indian_gt
GT=GT;

[m, n] = size(GT);

%%

GT2d = hyperConvert2d(GT);
GT2d(GT2d==0)=17;
CM = giveColorCM_HH(GT2d,m,n);

%%

figure;
imshow(uint8(CM));

%%

load('D:/ACGT-Net/ProcessingData\TE.mat');
load('D:/ACGT-Net/ProcessingData\TR.mat');

%% 文件读取阶段%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% mini-GCN

load('D:/ACGT-Net/ProcessingData\turns(i).mat');
turns=i;

% draw predicted classificaiton map
for i=1:turns
    strfile=["D:\ACGT-Net\features\features",num2str(i),".mat"];
    feature=strcat(strfile(1,1),strfile(1,2),strfile(1,3));
    load(feature);
    strfile_n=["D:\ACGT-Net\features\features_n",num2str(i),".mat"];
    feature_n=strcat(strfile_n(1,1),strfile_n(1,2),strfile_n(1,3));
    load(feature_n);
end

%% Transfer-GCN

load('D:/ACGT-Net/ProcessingData\Rturns.mat');

TLNumber=Rturns;
ReclassNum=0;
for i=1:TLNumber
    strfile_r=["D:\ACGT-Net\features\features_r",num2str(i),".mat"];
    feature_r=strcat(strfile_r(1,1),strfile_r(1,2),strfile_r(1,3));
    load(feature_r);
    currentfeature_r=strcat("features_r",num2str(i));
    CFeature_r=eval(currentfeature_r);
    ReclassNum=ReclassNum+size(CFeature_r,1);
end

map=zeros(m,n);
map_r=zeros(m,n);
map_feature=zeros(m,n,16);
load('D:\ACGT-Net/ProcessingData\TE_index2.mat','TE_index2');
feature_r_total=zeros(16,ReclassNum);

%% 图像拼接阶段%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% mini-GCN

load('D:/ACGT-Net/ProcessingData\t_Mod.mat');
if t_Mod~=0
    turns=turns-1;
end

for i=1:turns
    currentfeature=strcat("features",num2str(i));
    CFeature=eval(currentfeature);
    currentfeature_n=strcat("features_n",num2str(i));
    CFeature_n=eval(currentfeature_n);
    feature_combine=0.5*CFeature+0.5*CFeature_n;
    [~, ind] = max(feature_combine', [], 1);
    ind3d=hyperConvert3d(ind,m,20);
    feature_map=hyperConvert3d(feature_combine',m,20);
    map(1:m,(i-1)*20+1:i*20)=ind3d(1:m,1:20);
    map_feature(1:m,(i-1)*20+1:i*20,:)=feature_map(1:m,1:20,:);
end

if t_Mod~=0
    i=i+1;
    currentfeature=strcat("features",num2str(i));
    CFeature=eval(currentfeature);
    currentfeature_n=strcat("features_n",num2str(i));
    CFeature_n=eval(currentfeature_n);
    feature_combine=0.5*CFeature+0.5*CFeature_n;
    [~, ind] = max(feature_combine', [], 1);
    ind3d=hyperConvert3d(ind,m,5);
    feature_map=hyperConvert3d(feature_combine',m,5);
    map(1:m,(i-1)*20+1:(i-1)*20+5)=ind3d(1:m,1:5);
    map_feature(1:m,(i-1)*20+1:(i-1)*20+5,:)=feature_map(1:m,1:5,:);
end

%% Transfer-GCN

for i=1:TLNumber-1
    currentfeature_r=strcat("features_r",num2str(i));
    CFeature_r=eval(currentfeature_r);
    feature_r=CFeature_r;
    feature_r_total(:,(i-1)*7000+1:i*7000)=feature_r';
end

    i=i+1;
    currentfeature_r=strcat("features_r",num2str(i));
    CFeature_r=eval(currentfeature_r);
    feature_r=CFeature_r;
    feature_r_total(:,(i-1)*7000+1:ReclassNum)=feature_r';

%% 图像显示阶段%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% mini-GCN及1DCNN

map_feature2d=hyperConvert2d(map_feature);

%ACGT-Net
%ADD

% map_feature2d(:,TE_index2)=0.5*map_feature2d(:,TE_index2)+0.5*feature_r_total(:,:);

%Multi

map_feature2d(map_feature2d<0)=0.0001;
feature_r_total(feature_r_total<0)=0.0001;
map_feature2d(:,TE_index2)=map_feature2d(:,TE_index2).*feature_r_total(:,:);


[~,feature_max]=max(map_feature2d,[],1);
feature_map=hyperConvert3d(feature_max,m,n);

%% 

save('D:/ACGT-Net/ProcessingData\feature_map.mat','feature_map');

Pred_CM = feature_map;

Pred_CM = giveColorCM_HH(Pred_CM,m,n);


%%

figure;
imshow(uint8(Pred_CM));

%%  精度评定

load Indian_gt
TE=GT;

testIndexs=find(TE>0);
TE2d=hyperConvert2d(TE);
TE2d=TE2d';
testLabels=TE2d(testIndexs,:);

%%

AA1=zeros(10,1);
OA1=zeros(10,1);
KAPPA1=zeros(10,1);
CA1=zeros(16,10);
TstTime=zeros(10,1);
TrnTime=zeros(10,1);
SchTime=zeros(10,1);
zeros(10,1);   
tstart = tic;
for j=1:10
      %--------------------------计算精度------------------------------------------------------%
    pred=zeros(m,n);
    pred(testIndexs)=feature_map(testIndexs);
    [OA,kappa,AA,CA]=calcError(testLabels,pred(testIndexs), 1:16);
    OA1(j)=OA;
    AA1(j)=AA;
    KAPPA1(j)=kappa;
    CA1(:,j)=CA;
%     totaltime(j)=toc(tstart);
end
oa=mean(OA1)
stdoa=std(OA1);
aa=mean(AA1)
stdaa=std(AA1);
KAPPA=mean( KAPPA1)
stdKAPPA=std( KAPPA1);
stdca=std(CA1');
ca=mean(CA1')

function classification_map_rgb=giveColorCM_HH(classTest,m,n)
colorList = [0, 205, 0;
    127, 255, 0; 
    46, 139, 87; 
    0, 139, 0; 
    160, 82, 45; 
    0, 255, 255;
    255, 255, 255; 
    216, 191, 216; 
    255, 0, 0; 
    139, 0, 0; 
    0, 100, 255;
    255, 255, 0; 
    238, 154, 0; 
    85, 26, 139;
    255, 127, 80;
    0,0,205; 
    0,0,0;
    0,0,0;
    0,0,0;
    0,0,0;
    0,0,0;
    0,0,0;
    0,0,0;
    0,0,0;
    0,0,0;
    0,0,0];
classification_map_rgb = reshape(colorList(classTest,:),m,n,[]);
end

function [overall_accuracy,kappa_accuracy,average_accuracy,class_accuracy,errorMatrix] = calcError( trueLabelling, segLabelling, labels )  
% 计算OA，kppa，AA，CA
% calculates square array of numbers organized in rows and columns which express the
% percentage of pixels assigned to a particular category (in segLabelling) relative
% to the actual category as indicated by reference data (trueLabelling)
% errorMatrix(i,j) = nr of pixels that are of class i-1 and were
% classified as class j-1
% accuracy is essentially a measure of how many ground truth pixels were classified
% correctly (in percentage). 
% average accuracy is the average of the accuracies for each class
% overall accuracy is the accuracy of each class weighted by the proportion
% of test samples for that class in the total training set

% [nrX, nrY] = size(trueLabelling);
% totNrPixels = nrX*nrY;
nrPixelsPerClass = zeros(1,length(labels))';                               %0【16，1】
% nrClasses = length(labels);

errorMatrix = zeros(length(labels),length(labels));                        %0[16,16]
% errorMatrixPerc = zeros(length(labels),length(labels));

for l_true=1:length(labels)                                                %1:16
    tmp_true = find (trueLabelling == (l_true));
    nrPixelsPerClass(l_true) = length(tmp_true);                           %得到测试样本中每一类的数量，再依次赋值给nrPixelsPerClass(
    for l_seg=1:length(labels)                                             %1：16
        tmp_seg = find (segLabelling == (l_seg));                          %找出计算得到的Y中类为1-seg的索引
        nrPixels = length(intersect(tmp_true,tmp_seg));                    %比较理想索引与现实索引，得到相同的数量
        errorMatrix(l_true,l_seg) = nrPixels;  
    end
end

% classWeight = nrPixelsPerClass/totNrPixels;
diagVector = diag(errorMatrix);
class_accuracy = (diagVector./(nrPixelsPerClass));                         %每一个类的精度
average_accuracy = mean(class_accuracy);                                   %类的精度的平均
overall_accuracy = sum(segLabelling == trueLabelling)/length(trueLabelling);%总体相等的精度
kappa_accuracy = (sum(errorMatrix(:))*sum(diag(errorMatrix)) - sum(errorMatrix)*sum(errorMatrix,2))...
    /(sum(errorMatrix(:))^2 -  sum(errorMatrix)*sum(errorMatrix,2));

end

