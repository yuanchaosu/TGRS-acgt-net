
import math

import matplotlib
import numpy as np
import matplotlib.pyplot as plt
import scipy
import tensorflow as tf
import scipy.io as scio
import scipy.io as sio
from tensorflow.python.framework import ops
import matlab.engine

import time

eng = matlab.engine.start_matlab()

matplotlib.use('TkAgg')

###################################################################################################################################################################

eng.cd('D:\ACGT-Net\MATLAB_Function',nargout=0)

eng.Preprocessing_CSS(nargout=0)

Feature_Size = scio.loadmat('ProcessingData/Feature_Size.mat')
Feature_Size = Feature_Size['Feature_Size']
Feature_Size = int(Feature_Size)

ClassSize = scio.loadmat('ProcessingData/ClassSize.mat')
ClassSize = ClassSize['ClassSize']
ClassSize = int(ClassSize)

turns = scio.loadmat('ProcessingData/turns(i).mat')
turns = turns['i']
turns = int(turns)


###################################################################################################################################################################

def random_mini_batches_GCN(X, Y, L, mini_batch_size, seed):
    m = X.shape[0]
    mini_batches = []
    np.random.seed(seed)

    permutation = list(np.random.permutation(m))
    shuffled_X = X[permutation, :]
    shuffled_Y = Y[permutation, :].reshape((m, Y.shape[1]))
    shuffled_L1 = L[permutation, :].reshape((L.shape[0], L.shape[1]), order="F")
    shuffled_L = shuffled_L1[:, permutation].reshape((L.shape[0], L.shape[1]), order="F")

    num_complete_minibatches = math.floor(m / mini_batch_size)

    for k in range(0, num_complete_minibatches):
        mini_batch_X = shuffled_X[k * mini_batch_size: k * mini_batch_size + mini_batch_size, :]
        mini_batch_Y = shuffled_Y[k * mini_batch_size: k * mini_batch_size + mini_batch_size, :]
        mini_batch_L = shuffled_L[k * mini_batch_size: k * mini_batch_size + mini_batch_size,
                       k * mini_batch_size: k * mini_batch_size + mini_batch_size]
        mini_batch = (mini_batch_X, mini_batch_Y, mini_batch_L)
        mini_batches.append(mini_batch)
    mini_batch = (X, Y, L)
    mini_batches.append(mini_batch)

    return mini_batches

###################################################################################################################################################################

def convert_to_one_hot(Y, C):
    Y = np.eye(C)[Y.reshape(-1)].T
    return Y


def create_placeholders(n_x, n_y):
    isTraining = tf.compat.v1.placeholder_with_default(True, shape=())
    x_in = tf.compat.v1.placeholder(tf.float32, [None, n_x], name="x_in")
    y_in = tf.compat.v1.placeholder(tf.float32, [None, n_y], name="y_in")
    lap_train = tf.compat.v1.placeholder(tf.float32, [None, None], name="lap_train")

    return x_in, y_in, lap_train, isTraining


def initialize_parameters():
    tf.compat.v1.set_random_seed(1)

    x_w1 = tf.compat.v1.get_variable("x_w1", [Feature_Size, 32], initializer=tf.contrib.layers.xavier_initializer(seed=1))
    x_b1 = tf.compat.v1.get_variable("x_b1", [32], initializer=tf.zeros_initializer())

    x_w2 = tf.compat.v1.get_variable("x_w2", [32, ClassSize], initializer=tf.contrib.layers.xavier_initializer(seed=1))
    x_b2 = tf.compat.v1.get_variable("x_b2", [ClassSize], initializer=tf.zeros_initializer())

    parameters = {"x_w1": x_w1,
                  "x_b1": x_b1,
                  "x_w2": x_w2,
                  "x_b2": x_b2,
                  }

    return parameters


def GCN_layer(x_in, L_, weights):
    x_mid = tf.matmul(x_in, weights)
    x_out = tf.matmul(L_, x_mid)

    return x_out


def mynetwork(x, parameters, Lap, isTraining, momentums=0.9):
    with tf.name_scope("x_layer_1"):
        x_z1_bn = tf.layers.batch_normalization(x, momentum=momentums, training=isTraining)
        x_z1 = GCN_layer(x_z1_bn, Lap, parameters['x_w1']) + parameters['x_b1']
        x_z1_bn = tf.layers.batch_normalization(x_z1, momentum=momentums, training=isTraining)
        x_a1 = tf.nn.relu(x_z1_bn)

    with tf.name_scope("x_layer_2"):
        x_z2_bn = tf.layers.batch_normalization(x_a1, momentum=momentums, training=isTraining)
        x_z2 = GCN_layer(x_z2_bn, Lap, parameters['x_w2']) + parameters['x_b2']

    l2_loss = tf.nn.l2_loss(parameters['x_w1']) + tf.nn.l2_loss(parameters['x_w2'])

    return x_z2, l2_loss


def mynetwork_optimaization(y_est, y_re, l2_loss, reg, learning_rate, global_step):
    y_re = tf.squeeze(y_re, name='y_re')

    with tf.name_scope("cost"):
        cost = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits(logits=y_est, labels=y_re)) + reg * l2_loss

    with tf.name_scope("optimization"):
        update_ops = tf.compat.v1.get_collection(tf.compat.v1.GraphKeys.UPDATE_OPS)
    with tf.control_dependencies(update_ops):
        optimizer = tf.compat.v1.train.AdamOptimizer(learning_rate=learning_rate).minimize(cost,
                                                                                           global_step=global_step)
        optimizer = tf.group([optimizer, update_ops])

    return cost, optimizer


def network_accuracy(x_out, y_in):
    correct_prediction = tf.equal(tf.argmax(x_out, 1), tf.argmax(y_in, 1))
    accuracy = tf.reduce_mean(tf.cast(correct_prediction, "float"))

    return accuracy


def train_mynetwork(x_train, x_test, y_train, y_test, L_train, L_test, learning_rate_base=0.001, beta_reg=0.001,
                    num_epochs=400, minibatch_size=128, print_cost=True):
    ops.reset_default_graph()
    tf.compat.v1.set_random_seed(1)
    seed = 1
    (m, n_x) = x_train.shape
    (m, n_y) = y_train.shape

    costs = []
    costs_dev = []
    train_acc = []
    val_acc = []

    x_in, y_in, lap_train, isTraining = create_placeholders(n_x, n_y)

    parameters = initialize_parameters()

    with tf.name_scope("network"):
        x_out, l2_loss = mynetwork(x_in, parameters, lap_train, isTraining)

    global_step = tf.Variable(0, trainable=False)
    learning_rate = tf.compat.v1.train.exponential_decay(learning_rate_base, global_step, 50 * m / minibatch_size, 0.5,
                                                         staircase=True)

    with tf.name_scope("optimization"):
        cost, optimizer = mynetwork_optimaization(x_out, y_in, l2_loss, beta_reg, learning_rate, global_step)

    with tf.name_scope("metrics"):
        accuracy = network_accuracy(x_out, y_in)

    init = tf.compat.v1.global_variables_initializer()

    with tf.compat.v1.Session() as sess:

        sess.run(init)

        # Do the training loop
        for epoch in range(num_epochs + 1):
            epoch_cost = 0.
            epoch_acc = 0.

            num_minibatches = int(m / minibatch_size)  # number of minibatches of size minibatch_size in the train set
            seed = seed + 1

            minibatches = random_mini_batches_GCN(x_train, y_train, L_train, minibatch_size, seed)

            for minibatch in minibatches:
                # Select a minibatch
                (batch_x, batch_y, batch_l) = minibatch
                # IMPORTANT: The line that runs the graph on a minibatch.
                # Run the session to execute the "optimizer" and the "cost", the feedict should contain a minibatch for (X,Y).
                _, minibatch_cost, minibatch_acc = sess.run([optimizer, cost, accuracy],
                                                            feed_dict={x_in: batch_x, y_in: batch_y, lap_train: batch_l,
                                                                       isTraining: True})
                epoch_cost += minibatch_cost
                epoch_acc += minibatch_acc

            epoch_cost_train = epoch_cost / (num_minibatches + 1)
            epoch_acc_train = epoch_acc / (num_minibatches + 1)

            if print_cost == True and epoch % 50 == 0:
                features, epoch_cost_test, epoch_acc_test = sess.run([x_out, cost, accuracy],
                                                                     feed_dict={x_in: x_test, y_in: y_test,
                                                                                lap_train: L_test, isTraining: False})
                # print("epoch %i: Train_loss: %f, Val_loss: %f, Train_acc: %f, Val_acc: %f" % (
                # epoch, epoch_cost_train, epoch_cost_test, epoch_acc_train, epoch_acc_test))

            if print_cost == True and epoch % 5 == 0:
                costs.append(epoch_cost_train)
                train_acc.append(epoch_acc_train)
                costs_dev.append(epoch_cost_test)
                val_acc.append(epoch_acc_test)

        return parameters, val_acc, features

time_start_1 = time.time()
time_start_2 = time.time()

for i in range(1,turns+1):

    Train_X = scio.loadmat('HSI_GCN/Train_X' + str(i) + '.mat')
    TrLabel = scio.loadmat('HSI_GCN/TrLabel' + str(i) + '.mat')
    Test_X = scio.loadmat('HSI_GCN/Test_X' + str(i) + '.mat')
    TeLabel = scio.loadmat('HSI_GCN/TeLabel' + str(i) + '.mat')
    Train_L = scio.loadmat('HSI_GCN/Train_L' + str(i) + '.mat')
    Test_L = scio.loadmat('HSI_GCN/Test_L' + str(i) + '.mat')

    Train_X = Train_X['Train_X']
    Test_X = Test_X['Test_X']
    TrLabel = TrLabel['TrLabel']
    TeLabel = TeLabel['TeLabel']

    Train_L = Train_L['Train_L']
    Test_L = Test_L['Test_L']

    TrLabel = convert_to_one_hot(TrLabel - 1, ClassSize)
    TrLabel = TrLabel.T
    TeLabel = convert_to_one_hot(TeLabel - 1, ClassSize)
    TeLabel = TeLabel.T

    parameters, val_acc, features = train_mynetwork(Train_X, Test_X, TrLabel, TeLabel, Train_L, Test_L)
    scio.savemat('features/features' + str(i) + '.mat', {'features' + str(i): features})
    print(str(i) + "th Turn Finished！")
print("All Turn Finished！")


###########################################################################################################################################################################

def convert_to_one_hot(Y, C):
    Y = np.eye(C)[Y.reshape(-1)].T
    return Y


def create_placeholders(n_x, n_y):
    isTraining = tf.compat.v1.placeholder_with_default(True, shape=())
    x_in = tf.compat.v1.placeholder(tf.float32, [None, n_x], name="x_in")
    y_in = tf.compat.v1.placeholder(tf.float32, [None, n_y], name="y_in")
    lap_train = tf.compat.v1.placeholder(tf.float32, [None, None], name="lap_train")

    return x_in, y_in, lap_train, isTraining


def initialize_parameters():

    tf.compat.v1.set_random_seed(1)

    x_w1 = tf.compat.v1.get_variable("x_w1", [Feature_Size,32], initializer = tf.contrib.layers.xavier_initializer(seed = 1))
    x_b1 = tf.compat.v1.get_variable("x_b1", [32], initializer = tf.zeros_initializer())

    x_w2 = tf.compat.v1.get_variable("x_w2", [32,ClassSize], initializer = tf.contrib.layers.xavier_initializer(seed = 1))
    x_b2 = tf.compat.v1.get_variable("x_b2", [ClassSize], initializer = tf.zeros_initializer())


    parameters = {"x_w1": x_w1,
                  "x_b1": x_b1,
                  "x_w2": x_w2,
                  "x_b2": x_b2,
                  }

    return parameters


def GCN_layer(x_in, L_, weights):
    x_mid = tf.matmul(x_in, weights)
    x_out = tf.matmul(L_, x_mid)

    return x_out


def mynetwork(x, parameters, Lap, isTraining, momentums=0.9):

    with tf.name_scope("x_layer_1"):

         x_z1_bn = tf.layers.batch_normalization(x, momentum = momentums, training = isTraining)
         x_z1 = GCN_layer(x_z1_bn, Lap, parameters['x_w1']) + parameters['x_b1']
         x_z1_bn = tf.layers.batch_normalization(x_z1, momentum = momentums, training = isTraining)
         x_a1 = tf.nn.relu(x_z1_bn)

    with tf.name_scope("x_layer_2"):

         x_z2_bn = tf.layers.batch_normalization(x_a1, momentum = momentums, training = isTraining)
         x_z2 = GCN_layer(x_z2_bn, Lap, parameters['x_w2']) + parameters['x_b2']

    l2_loss = tf.nn.l2_loss(parameters['x_w1']) + tf.nn.l2_loss(parameters['x_w2'])

    return x_z2, l2_loss


def mynetwork_optimaization(y_est, y_re, l2_loss, reg, learning_rate, global_step):
    y_re = tf.squeeze(y_re, name='y_re')

    with tf.name_scope("cost"):
        cost = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits(logits=y_est, labels=y_re)) + reg * l2_loss

    with tf.name_scope("optimization"):
        update_ops = tf.compat.v1.get_collection(tf.compat.v1.GraphKeys.UPDATE_OPS)
    with tf.control_dependencies(update_ops):
        optimizer = tf.compat.v1.train.AdamOptimizer(learning_rate=learning_rate).minimize(cost,
                                                                                           global_step=global_step)
        optimizer = tf.group([optimizer, update_ops])

    return cost, optimizer


def network_accuracy(x_out, y_in):
    correct_prediction = tf.equal(tf.argmax(x_out, 1), tf.argmax(y_in, 1))
    accuracy = tf.reduce_mean(tf.cast(correct_prediction, "float"))

    return accuracy


def train_mynetwork(x_train, x_test, y_train, y_test, L_train, L_test, learning_rate_base=0.001, beta_reg=0.001,num_epochs=400, minibatch_size=128, print_cost=True):
    ops.reset_default_graph()
    tf.compat.v1.set_random_seed(1)
    seed = 1
    (m, n_x) = x_train.shape
    (m, n_y) = y_train.shape

    costs = []
    costs_dev = []
    train_acc = []
    val_acc = []

    x_in, y_in, lap_train, isTraining = create_placeholders(n_x, n_y)

    parameters = initialize_parameters()

    with tf.name_scope("network"):
        x_out, l2_loss = mynetwork(x_in, parameters, lap_train, isTraining)

    global_step = tf.Variable(0, trainable=False)
    learning_rate = tf.compat.v1.train.exponential_decay(learning_rate_base, global_step, 50 * m / minibatch_size, 0.5,
                                                         staircase=True)

    with tf.name_scope("optimization"):
        cost, optimizer = mynetwork_optimaization(x_out, y_in, l2_loss, beta_reg, learning_rate, global_step)

    with tf.name_scope("metrics"):
        accuracy = network_accuracy(x_out, y_in)

    init = tf.compat.v1.global_variables_initializer()

    with tf.compat.v1.Session() as sess:

        sess.run(init)

        # Do the training loop
        for epoch in range(num_epochs + 1):
            epoch_cost = 0.
            epoch_acc = 0.

            num_minibatches = int(m / minibatch_size)  # number of minibatches of size minibatch_size in the train set
            seed = seed + 1

            minibatches = random_mini_batches_GCN(x_train, y_train, L_train, minibatch_size, seed)

            for minibatch in minibatches:
                # Select a minibatch
                (batch_x, batch_y, batch_l) = minibatch
                # IMPORTANT: The line that runs the graph on a minibatch.
                # Run the session to execute the "optimizer" and the "cost", the feedict should contain a minibatch for (X,Y).
                _, minibatch_cost, minibatch_acc = sess.run([optimizer, cost, accuracy],
                                                            feed_dict={x_in: batch_x, y_in: batch_y, lap_train: batch_l,
                                                                       isTraining: True})
                epoch_cost += minibatch_cost
                epoch_acc += minibatch_acc

            epoch_cost_train = epoch_cost / (num_minibatches + 1)
            epoch_acc_train = epoch_acc / (num_minibatches + 1)

            if print_cost == True and epoch % 50 == 0:
                features, epoch_cost_test, epoch_acc_test = sess.run([x_out, cost, accuracy],
                                                                     feed_dict={x_in: x_test, y_in: y_test,
                                                                                lap_train: L_test, isTraining: False})
                # print("epoch %i: Train_loss: %f, Val_loss: %f, Train_acc: %f, Val_acc: %f" % (
                # epoch, epoch_cost_train, epoch_cost_test, epoch_acc_train, epoch_acc_test))

            if print_cost == True and epoch % 5 == 0:
                costs.append(epoch_cost_train)
                train_acc.append(epoch_acc_train)
                costs_dev.append(epoch_cost_test)
                val_acc.append(epoch_acc_test)

        return parameters, val_acc, features

for i in range(1,turns+1):


    Train_X = scio.loadmat('HSI_GCN/Train_X_n' + str(i) + '.mat')
    TrLabel = scio.loadmat('HSI_GCN/TrLabel_n' + str(i) + '.mat')
    Test_X = scio.loadmat('HSI_GCN/Test_X_n' + str(i) + '.mat')
    TeLabel = scio.loadmat('HSI_GCN/TeLabel_n' + str(i) + '.mat')
    Train_L = scio.loadmat('HSI_GCN/Train_L_n' + str(i) + '.mat')
    Test_L = scio.loadmat('HSI_GCN/Test_L_n' + str(i) + '.mat')

    Train_X = Train_X['Train_X_n']
    Test_X = Test_X['Test_X_n']
    TrLabel = TrLabel['TrLabel_n']
    TeLabel = TeLabel['TeLabel_n']

    Train_L = Train_L['Train_L_n']
    Test_L = Test_L['Test_L_n']

    TrLabel = convert_to_one_hot(TrLabel - 1, ClassSize)
    TrLabel = TrLabel.T
    TeLabel = convert_to_one_hot(TeLabel - 1, ClassSize)
    TeLabel = TeLabel.T

    parameters, val_acc, features = train_mynetwork(Train_X, Test_X, TrLabel, TeLabel, Train_L, Test_L)
    sio.savemat('features/features_n'+str(i)+'.mat', {'features_n'+str(i): features})
    print(str(i) + "th Turn Finished！")
print("All Turn Finished！")

time_end_1 = time.time()
print("运行时间："+str(time_end_1 - time_start_1)+"秒")

###########################################################################################################################################################################

def convert_to_one_hot(Y, C):
    Y = np.eye(C)[Y.reshape(-1)].T
    return Y


def create_placeholders(n_x, n_y):
    isTraining = tf.compat.v1.placeholder_with_default(True, shape=())
    x_in = tf.compat.v1.placeholder(tf.float32, [None, n_x], name="x_in")
    y_in = tf.compat.v1.placeholder(tf.float32, [None, n_y], name="y_in")
    lap_train = tf.compat.v1.placeholder(tf.float32, [None, None], name="lap_train")

    return x_in, y_in, lap_train, isTraining


def initialize_parameters():

    tf.compat.v1.set_random_seed(1)

    x_w1 = tf.compat.v1.get_variable("x_w1", [Feature_Size,32], initializer = tf.contrib.layers.xavier_initializer(seed = 1))
    x_b1 = tf.compat.v1.get_variable("x_b1", [32], initializer = tf.zeros_initializer())

    x_w2 = tf.compat.v1.get_variable("x_w2", [32,ClassSize], initializer = tf.contrib.layers.xavier_initializer(seed = 1))
    x_b2 = tf.compat.v1.get_variable("x_b2", [ClassSize], initializer = tf.zeros_initializer())


    parameters = {"x_w1": x_w1,
                  "x_b1": x_b1,
                  "x_w2": x_w2,
                  "x_b2": x_b2,
                  }

    return parameters


def GCN_layer(x_in, L_, weights):
    x_mid = tf.matmul(x_in, weights)
    x_out = tf.matmul(L_, x_mid)

    return x_out


def mynetwork(x, parameters, Lap, isTraining, momentums=0.9):

    with tf.name_scope("x_layer_1"):

         x_z1_bn = tf.layers.batch_normalization(x, momentum = momentums, training = isTraining)
         x_z1 = GCN_layer(x_z1_bn, Lap, parameters['x_w1']) + parameters['x_b1']
         x_z1_bn = tf.layers.batch_normalization(x_z1, momentum = momentums, training = isTraining)
         x_a1 = tf.nn.relu(x_z1_bn)

    with tf.name_scope("x_layer_2"):

         x_z2_bn = tf.layers.batch_normalization(x_a1, momentum = momentums, training = isTraining)
         x_z2 = GCN_layer(x_z2_bn, Lap, parameters['x_w2']) + parameters['x_b2']

    l2_loss = tf.nn.l2_loss(parameters['x_w1']) + tf.nn.l2_loss(parameters['x_w2'])

    return x_z2, l2_loss


def mynetwork_optimaization(y_est, y_re, l2_loss, reg, learning_rate, global_step):
    y_re = tf.squeeze(y_re, name='y_re')

    with tf.name_scope("cost"):
        cost = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits(logits=y_est, labels=y_re)) + reg * l2_loss

    with tf.name_scope("optimization"):
        update_ops = tf.compat.v1.get_collection(tf.compat.v1.GraphKeys.UPDATE_OPS)
    with tf.control_dependencies(update_ops):
        optimizer = tf.compat.v1.train.AdamOptimizer(learning_rate=learning_rate).minimize(cost,
                                                                                           global_step=global_step)
        optimizer = tf.group([optimizer, update_ops])

    return cost, optimizer


def network_accuracy(x_out, y_in):
    correct_prediction = tf.equal(tf.argmax(x_out, 1), tf.argmax(y_in, 1))
    accuracy = tf.reduce_mean(tf.cast(correct_prediction, "float"))

    return accuracy


def train_mynetwork(x_train, x_test, y_train, y_test, L_train, L_test, learning_rate_base=0.001, beta_reg=0.001,num_epochs=1600, minibatch_size=128, print_cost=True):
    ops.reset_default_graph()
    tf.compat.v1.set_random_seed(1)
    seed = 1
    (m, n_x) = x_train.shape
    (m, n_y) = y_train.shape

    costs = []
    costs_dev = []
    train_acc = []
    val_acc = []

    x_in, y_in, lap_train, isTraining = create_placeholders(n_x, n_y)

    parameters = initialize_parameters()

    with tf.name_scope("network"):
        x_out, l2_loss = mynetwork(x_in, parameters, lap_train, isTraining)

    global_step = tf.Variable(0, trainable=False)
    learning_rate = tf.compat.v1.train.exponential_decay(learning_rate_base, global_step, 50 * m / minibatch_size, 0.5,
                                                         staircase=True)

    with tf.name_scope("optimization"):
        cost, optimizer = mynetwork_optimaization(x_out, y_in, l2_loss, beta_reg, learning_rate, global_step)

    with tf.name_scope("metrics"):
        accuracy = network_accuracy(x_out, y_in)

    init = tf.compat.v1.global_variables_initializer()

    with tf.compat.v1.Session() as sess:

        sess.run(init)

        # Do the training loop
        for epoch in range(num_epochs + 1):
            epoch_cost = 0.
            epoch_acc = 0.

            num_minibatches = int(m / minibatch_size)  # number of minibatches of size minibatch_size in the train set
            seed = seed + 1

            minibatches = random_mini_batches_GCN(x_train, y_train, L_train, minibatch_size, seed)

            for minibatch in minibatches:
                # Select a minibatch
                (batch_x, batch_y, batch_l) = minibatch
                # IMPORTANT: The line that runs the graph on a minibatch.
                # Run the session to execute the "optimizer" and the "cost", the feedict should contain a minibatch for (X,Y).
                _, minibatch_cost, minibatch_acc = sess.run([optimizer, cost, accuracy],
                                                            feed_dict={x_in: batch_x, y_in: batch_y, lap_train: batch_l,
                                                                       isTraining: True})
                epoch_cost += minibatch_cost
                epoch_acc += minibatch_acc

            epoch_cost_train = epoch_cost / (num_minibatches + 1)
            epoch_acc_train = epoch_acc / (num_minibatches + 1)

            if print_cost == True and epoch % 50 == 0:
                features, epoch_cost_test, epoch_acc_test = sess.run([x_out, cost, accuracy],
                                                                     feed_dict={x_in: x_test, y_in: y_test,
                                                                                lap_train: L_test, isTraining: False})
                # print("epoch %i: Train_loss: %f, Val_loss: %f, Train_acc: %f, Val_acc: %f" % (
                # epoch, epoch_cost_train, epoch_cost_test, epoch_acc_train, epoch_acc_test))

            if print_cost == True and epoch % 5 == 0:
                costs.append(epoch_cost_train)
                train_acc.append(epoch_acc_train)
                costs_dev.append(epoch_cost_test)
                val_acc.append(epoch_acc_test)

        return parameters, val_acc, features


eng.draw_InitMap(nargout=0)
eng.ReclassificateKernal(nargout=0)

print("Left ACGT-Net")

Rturns = scio.loadmat('ProcessingData/Rturns.mat')
Rturns = Rturns['Rturns']
Rturns = int(Rturns)

for i in range(1,Rturns+1):

    Train_X = scio.loadmat('HSI_GCN/Train_X_r'+str(i)+'.mat')
    TrLabel = scio.loadmat('HSI_GCN/TrLabel_r'+str(i)+'.mat')
    Test_X = scio.loadmat('HSI_GCN/Test_X_r'+str(i)+'.mat')
    TeLabel = scio.loadmat('HSI_GCN/TeLabel_r'+str(i)+'.mat')
    Train_L = scio.loadmat('HSI_GCN/Train_L_r'+str(i)+'.mat')
    Test_L = scio.loadmat('HSI_GCN/Test_L_r'+str(i)+'.mat')

    Train_X = Train_X['Train_X_r']
    Test_X = Test_X['Test_X_r']
    TrLabel = TrLabel['TrLabel_r']
    TeLabel = TeLabel['TeLabel_r']

    Train_L = Train_L['Train_L_r']
    Test_L = Test_L['Test_L_r']

    TrLabel = convert_to_one_hot(TrLabel - 1, ClassSize)
    TrLabel = TrLabel.T
    TeLabel = convert_to_one_hot(TeLabel - 1, ClassSize)
    TeLabel = TeLabel.T

    parameters, val_acc, features = train_mynetwork(Train_X, Test_X, TrLabel, TeLabel, Train_L, Test_L)
    sio.savemat('features/features_r' + str(i) + '.mat', {'features_r' + str(i): features})
    print(str(i) + "th Turn Finished！")
print("All Turn Finished！")

time_end_2 = time.time()
print("运行时间："+str(time_end_2 - time_start_2)+"秒")

###########################################################################################################################################################################

def giveColorCM_HH(classTest, m, n):
    colorList = np.array([[0, 205, 0],
                          [127, 255, 0],
                          [46, 139, 87],
                          [0, 139, 0],
                          [160, 82, 45],
                          [0, 255, 255],
                          [255, 255, 255],
                          [216, 191, 216],
                          [255, 0, 0],
                          [139, 0, 0],
                          [0, 100, 255],
                          [255, 255, 0],
                          [238, 154, 0],
                          [85, 26, 139],
                          [255, 127, 80],
                          [0, 0, 205],
                          [0, 0, 0],
                          [0, 0, 0],
                          [0, 0, 0],
                          [0, 0, 0],
                          [0, 0, 0],
                          [0, 0, 0],
                          [0, 0, 0],
                          [0, 0, 0],
                          [0, 0, 0]])
    classification_map_rgb = colorList[classTest.flatten() - 1, :]
    classification_map_rgb = classification_map_rgb.reshape((m, n, -1))
    return classification_map_rgb.astype(np.uint8)

def calcError(trueLabelling, segLabelling, labels):
    nrPixelsPerClass = np.zeros(len(labels))
    errorMatrix = np.zeros((len(labels), len(labels)))

    for l_true in range(len(labels)):
        tmp_true = np.where(trueLabelling == labels[l_true])[0]
        nrPixelsPerClass[l_true] = len(tmp_true)
        for l_seg in range(len(labels)):
            tmp_seg = np.where(segLabelling == labels[l_seg])[0]
            nrPixels = len(np.intersect1d(tmp_true, tmp_seg))
            errorMatrix[l_true, l_seg] = nrPixels

    diagVector = np.diag(errorMatrix)
    class_accuracy = diagVector / nrPixelsPerClass
    average_accuracy = np.mean(class_accuracy)
    overall_accuracy = np.sum(segLabelling == trueLabelling) / len(trueLabelling)
    kappa_accuracy = (np.sum(errorMatrix) * np.sum(diagVector) - np.sum(errorMatrix) * np.sum(errorMatrix, axis=1)) / \
                     (np.sum(errorMatrix) ** 2 - np.sum(errorMatrix) * np.sum(errorMatrix, axis=1))

    return overall_accuracy, kappa_accuracy, average_accuracy, class_accuracy, errorMatrix

###########################################################################################################################################################################

# Load Indian_gt
GT = scipy.io.loadmat('Indian_gt.mat')['GT']
[m, n] = GT.shape

# Convert GT to 2D and assign label 17 to 0 values
GT2d = GT.reshape(-1)
GT2d[GT2d == 0] = 17

# Display ground truth
colorList = np.array([[0, 205, 0], [127, 255, 0], [46, 139, 87], [0, 139, 0], [160, 82, 45], [0, 255, 255], [255, 255, 255], [216, 191, 216], [255, 0, 0], [139, 0, 0]])
CM = np.zeros((m, n, 3), dtype=np.uint8)
for i in range(m):
    for j in range(n):
        CM[i, j] = colorList[GT2d[i*n+j] - 1]
plt.imshow(CM)
plt.show()

# Load TE and TR
TE = scipy.io.loadmat('D:/ACGT-Net/ProcessingData/TE.mat')
TR = scipy.io.loadmat('D:/ACGT-Net/ProcessingData/TR.mat')

# Load mini-GCN features
turns = scipy.io.loadmat('D:/ACGT-Net/ProcessingData/turns.mat')['i']

# Load predicted classification map
for i in range(1, turns + 1):
    feature = scipy.io.loadmat(f'D:/ACGT-Net/features/features{i}.mat')['features']
    feature_n = scipy.io.loadmat(f'D:/ACGT-Net/features/features_n{i}.mat')['features_n']

# Load Transfer-GCN features
Rturns = scipy.io.loadmat('D:/ACGT-Net/ProcessingData/Rturns.mat')['Rturns']

TLNumber = Rturns
ReclassNum = 0
feature_r_total = np.zeros((16, ReclassNum))
for i in range(1, TLNumber + 1):
    feature_r = scipy.io.loadmat(f'D:/ACGT-Net/features/features_r{i}.mat')['features_r']
    feature_r_total[:, (i - 1) * 7000 : i * 7000] = feature_r.T
    ReclassNum += feature_r.shape[0]

# Image stitching phase
map = np.zeros((m, n), dtype=np.uint8)
map_r = np.zeros((m, n), dtype=np.uint8)
map_feature = np.zeros((m, n, 16), dtype=np.float32)

t_Mod = scipy.io.loadmat('D:/ACGT-Net/ProcessingData/t_Mod.mat')['t_Mod']

if t_Mod != 0:
    turns -= 1

for i in range(1, turns + 1):
    feature = scipy.io.loadmat(f'D:/ACGT-Net/features/features{i}.mat')['features']
    feature_n = scipy.io.loadmat(f'D:/ACGT-Net/features/features_n{i}.mat')['features_n']
    feature_combine = 0.5 * feature + 0.5 * feature_n
    ind = np.argmax(feature_combine, axis=1)
    ind3d = ind.reshape(m, 20)
    feature_map = feature_combine.reshape(m, 20, -1)
    map[:, (i - 1) * 20 : i * 20] = ind3d
    map_feature[:, (i - 1) * 20 : i * 20, :] = feature_map

if t_Mod != 0:
    i += 1
    feature = scipy.io.loadmat(f'D:/ACGT-Net/features/features{i}.mat')['features']
    feature_n = scipy.io.loadmat(f'D:/ACGT-Net/features/features_n{i}.mat')['features_n']
    feature_combine = 0.5 * feature + 0.5 * feature_n
    ind = np.argmax(feature_combine, axis=1)
    ind3d = ind.reshape(m, 5)
    feature_map = feature_combine.reshape(m, 5, -1)
    map[:, (i - 1) * 20 : (i - 1) * 20 + 5] = ind3d
    map_feature[:, (i - 1) * 20 : (i - 1) * 20 + 5, :] = feature_map

for i in range(1, TLNumber):
    feature_r = scipy.io.loadmat(f'D:/ACGT-Net/features/features_r{i}.mat')['features_r']
    feature_r_total[:, (i - 1) * 7000 : i * 7000] = feature_r.T

i += 1
feature_r = scipy.io.loadmat(f'D:/ACGT-Net/features/features_r{i}.mat')['features_r']
feature_r_total[:, (i - 1) * 7000 : ReclassNum] = feature_r.T

# Display image
map_feature2d = map_feature.reshape(-1, 16)
TE_index2 = scipy.io.loadmat('D:/ACGT-Net/ProcessingData/TE_index2.mat')['TE_index2'].reshape(-1)

# ACGT-Multi
map_feature2d[map_feature2d < 0] = 0.0001
feature_r_total[feature_r_total < 0] = 0.0001
map_feature2d[:, TE_index2] = map_feature2d[:, TE_index2] * feature_r_total[:, :]

# ACGT-Add
map_feature2d[:, TE_index2] = map_feature2d[:, TE_index2] + feature_r_total[:, :]

feature_max = np.argmax(map_feature2d, axis=1)
feature_map = feature_max.reshape(m, n)

# Save feature map
scipy.io.savemat('D:/ACGT-Net/ProcessingData/feature_map.mat', {'feature_map': feature_map})

# Display predicted classification map
Pred_CM = feature_map
Pred_CM = giveColorCM_HH(Pred_CM, m, n)

plt.imshow(Pred_CM)
plt.show()

# Accuracy evaluation
TE = scipy.io.loadmat('Indian_gt.mat')['GT']
TE2d = TE.T.reshape(-1)
testIndexs = np.where(TE2d > 0)[0]
testLabels = TE2d[testIndexs]

AA1 = np.zeros(10)
OA1 = np.zeros(10)
KAPPA1 = np.zeros(10)
CA1 = np.zeros((16, 10))
TstTime = np.zeros(10)
TrnTime = np.zeros(10)
SchTime = np.zeros(10)
totaltime = np.zeros(10)

for j in range(10):
    pred = np.zeros((m, n), dtype=np.uint8)
    pred[testIndexs] = feature_map[testIndexs]
    OA, kappa, AA, CA = calcError(testLabels, pred[testIndexs], np.arange(1, 17))
    OA1[j] = OA
    AA1[j] = AA
    KAPPA1[j] = kappa
    CA1[:, j] = CA

oa = np.mean(OA1)
stdoa = np.std(OA1)
aa = np.mean(AA1)
stdaa = np.std(AA1)
KAPPA = np.mean(KAPPA1)
stdKAPPA = np.std(KAPPA1)
stdca = np.std(CA1, axis=1)
ca = np.mean(CA1, axis=1)
